from cryptography.fernet import Fernet
import base64
import os

class Encryption:
    def __init__(self):
        # Try to get key from environment variable
        self.key_file = "secret.key"
        self.key = os.environ.get('ENCRYPTION_KEY')
        
        if self.key:
            # Key provided in env, ensure it's bytes
            if isinstance(self.key, str):
                self.key = self.key.encode()
        else:
            # Try to load from file
            if os.path.exists(self.key_file):
                with open(self.key_file, "rb") as key_file:
                    self.key = key_file.read().strip()
            
            # If still no key, generate new one
            if not self.key:
                self.key = Fernet.generate_key()
                with open(self.key_file, "wb") as key_file:
                    key_file.write(self.key)
        
        # Validate key
        try:
            # Fernet key must be 32 url-safe base64-encoded bytes
            self.cipher = Fernet(self.key)
        except Exception as e:
            print(f"Invalid encryption key: {e}")
            # Fallback to new key if invalid (DANGEROUS if data already encrypted, but better than crashing)
            # In production, we should probably raise error
            print("Generating new key as fallback...")
            self.key = Fernet.generate_key()
            self.cipher = Fernet(self.key)
            with open(self.key_file, "wb") as key_file:
                key_file.write(self.key)
    
    def encrypt(self, data: str) -> str:
        """Encrypt data"""
        if not data:
            return ""
        try:
            encrypted_data = self.cipher.encrypt(data.encode())
            # Return as base64 string
            return base64.b64encode(encrypted_data).decode('utf-8')
        except Exception as e:
            print(f"Encryption error: {e}")
            return ""
    
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt data"""
        if not encrypted_data:
            return ""
        try:
            # Decode base64 first
            encrypted_bytes = base64.b64decode(encrypted_data.encode('utf-8'))
            decrypted_data = self.cipher.decrypt(encrypted_bytes)
            return decrypted_data.decode('utf-8')
        except Exception as e:
            print(f"Decryption error: {e}")
            return ""
