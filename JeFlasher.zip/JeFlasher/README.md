# JeFlasher - Telegram Cryptocurrency Flashing Bot

A comprehensive Telegram bot that provides subscription-based cryptocurrency flashing services for aesthetic purposes on the Ethereum blockchain.

## Features

### Subscription Management
- **Three Subscription Tiers**: Daily, Weekly, and Monthly
- **Secure Payment Processing**: Blockchain-based payment verification
- **Automatic Activation**: Subscriptions activate upon confirmed payment

### Cryptocurrency Flashing
- **Multiple Tokens**: Support for USDC, USDT, and DAI
- **Dual-Mode System**: 
  - Fast Mode: Higher gas fees for quick visibility
  - Long Mode: Lower gas fees for extended duration
- **Aesthetic Transactions**: Creates pending transactions that appear on Etherscan

### Security Features
- **Encrypted Private Keys**: All private keys are encrypted before storage
- **Wallet Address Validation**: Comprehensive address verification
- **Admin Controls**: Secure admin panel for user management

### User Experience
- **Intuitive Interface**: Easy-to-use command system
- **Real-time Status Updates**: Track subscription and transaction status
- **Comprehensive Help**: Detailed instructions and guidance

## Setup Instructions

### 1. Prerequisites
- Python 3.8+
- Telegram Bot Token
- Ethereum RPC endpoint (Infura, Alchemy, etc.)
- Etherscan API key

### 2. Installation

```bash
# Clone the repository
git clone <repository-url>
cd JeFlasher

# Install dependencies
pip install -r requirements.txt

# Copy environment configuration
cp .env.example .env
```

### 3. Configuration

Edit the `.env` file with your settings:

```bash
# Required
BOT_TOKEN=your_telegram_bot_token_here
ADMIN_USER_ID=8374440795
ETH_RPC_URL=https://mainnet.infura.io/v3/your_project_id
ETHERSCAN_API_KEY=your_etherscan_api_key

# Optional - Subscription Prices
DAILY_PRICE=10
WEEKLY_PRICE=50
MONTHLY_PRICE=150
```

### 4. Running the Bot

```bash
python bot.py
```

## Available Commands

### User Commands
- `/start` - Welcome message and status
- `/help` - Comprehensive help guide
- `/status` - Check subscription and wallet status
- `/buy` - Purchase subscription
- `/setwallet` - Set Ethereum wallet address
- `/setkey` - Set private key for flashing
- `/flash` - Create flash transactions
- `/history` - View flash history

### Admin Commands
- `/show <user_id>` - View user private key (admin only)

## How It Works

### 1. Subscription Process
1. User runs `/buy` command
2. Selects subscription tier (daily/weekly/monthly)
3. Receives payment instructions with exact amount
4. Makes payment to specified wallet address
5. Clicks "I Paid" button for verification
6. Subscription activates automatically

### 2. Flashing Process
1. User runs `/flash` command (requires active subscription)
2. Selects token type (USDC/USDT/DAI)
3. Chooses flash amount
4. Selects mode (Fast/Long)
5. Transaction is created and broadcast
6. User receives Etherscan link

### 3. Transaction Characteristics
- **Zero Value**: ETH value set to 0
- **Low Gas**: Configured to delay mining
- **Pending Status**: Appears as pending on Etherscan
- **Eventual Rejection**: Transactions are rejected without confirmation

## Important Notes

### Security
- Private keys are encrypted using industry-standard cryptography
- Admin access is restricted to specified user ID
- Users are warned to only deposit minimal ETH for gas fees
- All transactions are for aesthetic purposes only

### Limitations
- No actual value transfer occurs
- Transactions will be rejected by the network
- Requires ETH balance for gas fees
- Subscription-based access control

### Best Practices
- Only deposit minimal ETH (0.001-0.01) for gas fees
- Never share private keys in public
- Use dedicated wallets for this service
- Monitor gas prices for optimal timing

## Technical Architecture

### Database Schema
- **Users**: User information and wallet data
- **Subscriptions**: Subscription details and status
- **Flash History**: Transaction records
- **Payment Verification**: Payment tracking

### Dependencies
- `python-telegram-bot`: Telegram bot framework
- `web3.py`: Ethereum blockchain interaction
- `cryptography`: Private key encryption
- `python-dotenv`: Environment configuration

## Support

For support and questions:
1. Use `/help` command in the bot
2. Check the comprehensive help guide
3. Contact the admin user

## Disclaimer

This bot is for educational and aesthetic purposes only. No real value is transferred, and transactions are designed to be rejected by the network. Users are responsible for their private keys and wallet security.