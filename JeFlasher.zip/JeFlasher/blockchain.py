import os
from web3 import Web3
try:
    from web3.middleware import ExtraDataToPOAMiddleware
except ImportError:
    from web3.middleware import geth_poa_middleware as ExtraDataToPOAMiddleware

import requests
from typing import Optional, Dict, Any
from decimal import Decimal
import secrets
import random
import time
import base58

try:
    from solana.rpc.api import Client
    from solana.transaction import Transaction
    from solders.keypair import Keypair
    from solders.pubkey import Pubkey
    from solders.system_program import Transfer, TransferParams
    SOLANA_AVAILABLE = True
except ImportError:
    SOLANA_AVAILABLE = False

class BlockchainUtils:
    def __init__(self):
        # Ethereum
        self.w3 = Web3(Web3.HTTPProvider(os.getenv('ETH_RPC_URL', 'https://mainnet.infura.io/v3/ac29508311be412ba6b25b9254b7517e')))
        
        # Polygon
        self.w3_polygon = Web3(Web3.HTTPProvider(os.getenv('POLYGON_RPC_URL', 'https://rpc.ankr.com/polygon/837fd829b5cf0adb3cfff71ded33124051e25c1035b65f5ebe5179f5dd894c57')))
        
        # Metis - Removed
        
        # Add POA middleware for some networks
        try:
            self.w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
        except Exception as e:
            print(f"Failed to inject POA middleware (ETH): {e}")
            
        try:
            self.w3_polygon.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
        except Exception as e:
            print(f"Failed to inject POA middleware (Polygon): {e}")
        
        self.etherscan_api_key = os.getenv('ETHERSCAN_API_KEY', '')
        
        # Token contract addresses (Ethereum)
        self.token_contracts = {
            'USDC': os.getenv('USDC_CONTRACT', '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48'),
            'USDT': os.getenv('USDT_CONTRACT', '0xdAC17F958D2ee523a2206206994597C13D831ec7'),
            'DAI': os.getenv('DAI_CONTRACT', '0x6B175474E89094C44Da98b954EedeAC495271d0F'),
            'UNI': '0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984',
            'LINK': '0x514910771AF9Ca656af840dff83E8264EcF986CA'
        }
        
        # Polygon Token Contracts
        self.polygon_contracts = {
            'USDC': '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
            'USDT': '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
            'DAI': '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
            'UNI': '0xb33EaAd8d922B1083446DC23f610c2567fB5180f',
            'LINK': '0x53E0bca35eC356BD5ddDFebbD1Fc0fD03FaBad39'
        }

        # Token decimals
        self.token_decimals = {
            'USDC': 6,
            'USDT': 6,
            'DAI': 18,
            'UNI': 18,
            'LINK': 18,
            'MATIC': 18,
            'ETH': 18
        }
        
        # ERC20 ABI for token interactions
        self.erc20_abi = [
            {
                "constant": True,
                "inputs": [{"name": "_owner", "type": "address"}],
                "name": "balanceOf",
                "outputs": [{"name": "balance", "type": "uint256"}],
                "type": "function"
            },
            {
                "constant": False,
                "inputs": [
                    {"name": "_to", "type": "address"},
                    {"name": "_value", "type": "uint256"}
                ],
                "name": "transfer",
                "outputs": [{"name": "", "type": "bool"}],
                "type": "function"
            }
        ]
    
    def get_provider(self, network='ETH'):
        if network == 'POLYGON':
            return self.w3_polygon
        return self.w3
    
    def is_connected(self, network='ETH') -> bool:
        """Check if connected to network"""
        return self.get_provider(network).is_connected()
    
    def validate_address(self, address: str, network='ETH') -> bool:
        """Validate address"""
        if network == 'SOLANA':
            # Basic Solana address validation (length 32-44 base58 chars)
            return len(address) >= 32 and len(address) <= 44
        try:
            return self.get_provider(network).is_address(address)
        except:
            return False
    
    def to_checksum_address(self, address: str, network='ETH') -> str:
        """Convert to checksum address"""
        if network == 'SOLANA':
            return address
        return self.get_provider(network).to_checksum_address(address)
    
    def verify_payment(self, wallet_address: str, expected_amount: float, 
                      tx_hash: str) -> Dict[str, Any]:
        """Verify payment transaction (Always ETH for subscription)"""
        try:
            # Get transaction details
            tx = self.w3.eth.get_transaction(tx_hash)
            
            if not tx:
                return {'success': False, 'error': 'Transaction not found'}
            
            # Check if transaction is to the expected wallet
            if tx['to'].lower() != wallet_address.lower():
                return {'success': False, 'error': 'Transaction not to expected address'}
            
            # Get transaction receipt
            receipt = self.w3.eth.get_transaction_receipt(tx_hash)
            
            if not receipt or receipt['status'] != 1:
                return {'success': False, 'error': 'Transaction failed or not confirmed'}
            
            # Check amount (convert from Wei to ETH)
            tx_value = Decimal(self.w3.from_wei(tx['value'], 'ether'))
            expected = Decimal(str(expected_amount))
            
            # Allow for small floating point differences (e.g. 0.00000001)
            if tx_value < expected - Decimal('0.00000001'):
                return {
                    'success': False, 
                    'error': f'Insufficient amount. Expected: {expected}, Got: {tx_value}'
                }
            
            return {
                'success': True,
                'tx_hash': tx_hash,
                'amount': float(tx_value),
                'from_address': tx['from'],
                'block_number': tx['blockNumber']
            }
            
        except Exception as e:
            return {'success': False, 'error': f'Verification error: {str(e)}'}
    
    def get_explorer_url(self, tx_hash: str, network: str = 'ETH') -> str:
        """Get explorer URL for transaction"""
        if network == 'POLYGON':
            return f"https://polygonscan.com/tx/{tx_hash}"
        elif network == 'SOLANA':
            return f"https://solscan.io/tx/{tx_hash}"
        return f"https://etherscan.io/tx/{tx_hash}"
    
    def generate_fake_solana_signature(self) -> str:
        """Generate a fake Solana signature"""
        chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        return "".join(random.choice(chars) for _ in range(88))

    def create_flash_transaction(self, private_key: str, token_type: str, amount: float, 
                               target_address: str, mode: str = 'long', network: str = 'ETH', flash_method: str = 'standard') -> Dict[str, Any]:
        """Create a flash transaction"""
        try:
            if network == 'SOLANA':
                # Try to send real transaction if library available to get real TXID
                if SOLANA_AVAILABLE:
                    # List of RPCs to try
                    rpc_urls = [
                        os.getenv('SOLANA_RPC_URL', 'https://api.mainnet-beta.solana.com'),
                        'https://api.mainnet-beta.solana.com',
                        'https://solana-api.projectserum.com',
                        'https://rpc.ankr.com/solana'
                    ]
                    
                    last_error = None
                    
                    for rpc_url in rpc_urls:
                        try:
                            client = Client(rpc_url)
                            
                            # Decode key
                            try:
                                key_bytes = base58.b58decode(private_key)
                            except:
                                import json
                                key_bytes = bytes(json.loads(private_key))
                                
                            sender = Keypair.from_bytes(key_bytes)
                            receiver = Pubkey.from_string(target_address)
                            
                            # Check balance for fee (approx 5000 lamports)
                            try:
                                balance_resp = client.get_balance(sender.pubkey())
                                balance = balance_resp.value
                                if balance < 5000:
                                    raise Exception(f"Insufficient SOL for fee. Balance: {balance} lamports")
                            except Exception as e:
                                print(f"Error checking balance on {rpc_url}: {e}")
                                last_error = e
                                continue # Try next RPC
                                
                            # Get recent blockhash
                            recent_blockhash = client.get_latest_blockhash().value.blockhash

                            # METHOD 1: Standard (0 SOL Transfer)
                            if flash_method == 'standard' or flash_method == 'data_spoof': # Default
                                ix = Transfer(
                                    TransferParams(
                                        from_pubkey=sender.pubkey(),
                                        to_pubkey=receiver,
                                        lamports=0
                                    )
                                )
                                txn = Transaction().add(ix)
                            
                            # METHOD 2: Memo Spoof (0 SOL + Memo)
                            elif flash_method == 'zero_memo':
                                # Memo Program ID: MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcQb
                                from solders.instruction import Instruction
                                memo_program_id = Pubkey.from_string("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcQb")
                                memo_data = f"Transfer {amount} {token_type}".encode("utf-8")
                                
                                memo_ix = Instruction(
                                    program_id=memo_program_id,
                                    accounts=[],
                                    data=memo_data
                                )
                                
                                transfer_ix = Transfer(
                                    TransferParams(
                                        from_pubkey=sender.pubkey(),
                                        to_pubkey=receiver,
                                        lamports=0
                                    )
                                )
                                txn = Transaction().add(transfer_ix).add(memo_ix)

                            # METHOD 3: Token Sim (Fake Token Transfer)
                            elif flash_method == 'fake_contract':
                                 # Just use Memo but with "Interaction" text
                                from solders.instruction import Instruction
                                memo_program_id = Pubkey.from_string("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcQb")
                                memo_data = f"Program: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA".encode("utf-8")
                                
                                memo_ix = Instruction(
                                    program_id=memo_program_id,
                                    accounts=[],
                                    data=memo_data
                                )
                                txn = Transaction().add(memo_ix) # Just memo
                            
                            else:
                                 ix = Transfer(
                                    TransferParams(
                                        from_pubkey=sender.pubkey(),
                                        to_pubkey=receiver,
                                        lamports=0
                                    )
                                )
                                 txn = Transaction().add(ix)

                            # Sign and Send
                            txn.recent_blockhash = recent_blockhash
                            txn.fee_payer = sender.pubkey() # Set fee payer
                            
                            # New solana-py send_transaction might expect different args
                            result = client.send_transaction(txn, sender)
                            
                            # Check if result has value (signature)
                            if hasattr(result, 'value'):
                                tx_hash = str(result.value)
                            else:
                                tx_hash = str(result) # fallback
                            
                            return {
                                'success': True,
                                'tx_hash': tx_hash,
                                'from_address': str(sender.pubkey()),
                                'to_address': target_address,
                                'amount': amount,
                                'token_type': token_type,
                                'mode': mode,
                                'network': 'SOLANA',
                                'method': flash_method
                            }
                            
                        except Exception as e:
                            print(f"Solana real TX failed on {rpc_url}: {e}")
                            last_error = e
                            continue # Try next RPC

                    # If all RPCs failed
                    print(f"All Solana RPCs failed. Last error: {last_error}")
                    # Fallback to fake
                    
                # Mock Solana transaction
                return {
                    'success': True,
                    'tx_hash': self.generate_fake_solana_signature(),
                    'from_address': 'SolanaWallet',
                    'to_address': target_address,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': 'SOLANA'
                }

            w3 = self.get_provider(network)
            if network == 'POLYGON':
                contracts = self.polygon_contracts
            else:
                contracts = self.token_contracts
            
            # Get account from private key
            account = w3.eth.account.from_key(private_key)
            from_address = account.address
            
            # Get token contract or handle native token
            is_native = False
            contract_address = None
            
            if token_type in ['ETH', 'MATIC']:
                if (network == 'ETH' and token_type == 'ETH') or \
                   (network == 'POLYGON' and token_type == 'MATIC'):
                    is_native = True
                else:
                    return {'success': False, 'error': f'{token_type} not supported on {network}'}
            elif token_type == 'SOL' and network == 'SOLANA':
                 is_native = True # Handled in special block above but good to keep consistent
            elif token_type not in contracts:
                return {'success': False, 'error': 'Invalid token type'}
            else:
                contract_address = self.to_checksum_address(contracts[token_type], network)
            
            target_checksum = self.to_checksum_address(target_address, network)
            
            # Get current nonce (pending to include transactions in mempool)
            nonce = w3.eth.get_transaction_count(from_address, 'pending')
            
            # Get current gas price
            base_gas_price = w3.eth.gas_price
            
            # Set gas price based on mode
            if mode == 'superfast':
                gas_price = int(base_gas_price * 3.0) # Very high gas price for instant inclusion
            elif mode == 'fast':
                gas_price = int(base_gas_price * 1.5)  # Higher gas price
            else:  # long mode
                gas_price = int(base_gas_price * 0.8)  # Lower gas price
            
            # Convert amount to token decimals/wei
            decimals = self.token_decimals.get(token_type, 18)
            token_amount = int(amount * 10**decimals)

            # METHOD 2: Data Spoofing (On-Chain Confirmed)
            if flash_method == 'data_spoof':
                spoof_value = 0
                
                # Try to send a tiny amount of ETH if possible (e.g. 0.00001) to make it look real
                try:
                    balance = w3.eth.get_balance(from_address)
                    tiny_amount = w3.to_wei(0.00001, 'ether')
                    if balance > (tiny_amount + w3.to_wei(0.002, 'ether')): # Gas buffer
                        spoof_value = tiny_amount
                except:
                    pass
                
                # Construct Data
                if is_native:
                    # For ETH, we just send 0 ETH (or tiny) to target.
                    # Add data to make it look like a transfer if viewed raw
                    tx_data = w3.to_hex(text="Flash Transfer")
                else:
                    # For Tokens, we spoof the transfer function call using manual encoding
                    # Function selector for transfer(address,uint256) is 0xa9059cbb
                    selector = "0xa9059cbb"
                    
                    # Pad address to 32 bytes (64 hex chars)
                    # target_checksum is '0x...' (42 chars). Remove 0x.
                    addr_clean = target_checksum[2:]
                    addr_padded = addr_clean.zfill(64)
                    
                    # Pad amount to 32 bytes
                    amount_hex = hex(token_amount)[2:] # remove 0x
                    amount_padded = amount_hex.zfill(64)
                    
                    tx_data = selector + addr_padded + amount_padded
                
                tx_params = {
                    'from': from_address,
                    'to': target_checksum, # Send directly to target EOA to avoid revert if contract
                    'value': spoof_value,
                    'gas': 100000, # Increased gas for data transfer safety
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': w3.eth.chain_id,
                    'data': tx_data
                }
                
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                
                return {
                    'success': True,
                    'tx_hash': w3.to_hex(tx_hash),
                    'from_address': from_address,
                    'to_address': target_checksum,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': network,
                    'gas_price': gas_price,
                    'method': 'data_spoof'
                }

            # METHOD 3: Future Nonce (Ghost)
            if flash_method == 'ghost':
                # Use current nonce + gap (e.g., 1) to keep it pending
                nonce = nonce + 1
                
                # Standard transfer logic but with future nonce
                if is_native:
                    tx_params = {
                        'from': from_address,
                        'to': target_checksum,
                        'value': token_amount,
                        'gas': 21000,
                        'gasPrice': gas_price,
                        'nonce': nonce,
                        'chainId': w3.eth.chain_id
                    }
                    signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                else:
                    contract = w3.eth.contract(address=contract_address, abi=self.erc20_abi)
                    try:
                        gas_limit = 100000
                    except:
                        gas_limit = 100000
                    
                    tx_data = contract.functions.transfer(
                        target_checksum,
                        token_amount
                    ).build_transaction({
                        'from': from_address,
                        'gas': gas_limit,
                        'gasPrice': gas_price,
                        'nonce': nonce,
                        'value': 0, # Value is 0 ETH for token transfer
                        'chainId': w3.eth.chain_id
                    })
                    signed_tx = w3.eth.account.sign_transaction(tx_data, private_key)
                
                # Broadcast
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                
                return {
                    'success': True,
                    'tx_hash': w3.to_hex(tx_hash),
                    'from_address': from_address,
                    'to_address': contract_address if contract_address else target_checksum,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': network,
                    'gas_price': gas_price,
                    'method': 'ghost'
                }

            # METHOD 4: Zero Value with Memo (Transfer with Note)
            if flash_method == 'zero_memo':
                # Send 0 value but with Input Data saying "Sent <amount> <token>"
                memo = f"Sent {amount} {token_type}".encode('utf-8').hex()
                
                tx_params = {
                    'from': from_address,
                    'to': target_checksum,
                    'value': 0,
                    'gas': 30000,
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': w3.eth.chain_id,
                    'data': '0x' + memo
                }
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                
                return {
                    'success': True,
                    'tx_hash': w3.to_hex(tx_hash),
                    'from_address': from_address,
                    'to_address': target_checksum,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': network,
                    'method': 'zero_memo'
                }

            # METHOD 5: Fake Contract Interaction (Random Contract)
            if flash_method == 'fake_contract':
                # Interact with a random address as if it's a contract
                # This will likely just be a transfer to EOA or call to empty address (Success)
                # But we structure it like a token transfer
                
                # Generate a random address to act as "fake token contract"
                fake_contract = w3.eth.account.create().address
                
                # Encode transfer
                selector = "0xa9059cbb"
                addr_clean = target_checksum[2:]
                addr_padded = addr_clean.zfill(64)
                amount_hex = hex(token_amount)[2:]
                amount_padded = amount_hex.zfill(64)
                tx_data = selector + addr_padded + amount_padded
                
                tx_params = {
                    'from': from_address,
                    'to': fake_contract, # Send to fake contract
                    'value': 0,
                    'gas': 100000,
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': w3.eth.chain_id,
                    'data': tx_data
                }
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                
                return {
                    'success': True,
                    'tx_hash': w3.to_hex(tx_hash),
                    'from_address': from_address,
                    'to_address': fake_contract,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': network,
                    'method': 'fake_contract'
                }

            # METHOD 6: Revert / OOG (Out of Gas)
            if flash_method == 'revert_oog':
                # For Tokens: Send valid transfer to Real Contract but with 0 ETH balance
                # This causes "Transfer amount exceeds balance" Revert on chain
                if not is_native and contract_address:
                    contract = w3.eth.contract(address=contract_address, abi=self.erc20_abi)
                    
                    # Build transaction data
                    tx_data = contract.functions.transfer(
                        target_checksum,
                        token_amount
                    ).build_transaction({
                        'from': from_address,
                        'gas': 100000, # Sufficient gas to start execution
                        'gasPrice': gas_price,
                        'nonce': nonce,
                        'value': 0,
                        'chainId': w3.eth.chain_id
                    })
                    signed_tx = w3.eth.account.sign_transaction(tx_data, private_key)
                    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                    
                    return {
                        'success': True,
                        'tx_hash': w3.to_hex(tx_hash),
                        'from_address': from_address,
                        'to_address': contract_address, # Interaction with contract
                        'amount': amount,
                        'token_type': token_type,
                        'mode': mode,
                        'network': network,
                        'method': 'revert_oog'
                    }
                
                # For ETH/Native: Try OOG by sending data to target with low gas
                # Note: Hard to force fail on EOA, but we'll try sending with data
                tx_params = {
                    'from': from_address,
                    'to': target_checksum,
                    'value': 0, 
                    'gas': 22000, # Slightly above 21000
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': w3.eth.chain_id,
                    'data': '0x12345678' # Small data: 4 bytes = 64 gas. 21000+64 = 21064.
                }
                # This likely succeeds for EOA, but might look weird. 
                # Improving: Send to a known contract that always reverts? No, too complex.
                # Let's just use the data spoof method logic but with explicit fail attempt?
                # Actually, let's just keep the old OOG logic but refined.
                
                tx_params['data'] = '0xff' * 50 # 50 bytes. Cost: 50*16 = 800. 21800.
                tx_params['gas'] = 22000 # 22000 > 21800. Should broadcast.
                # If target is EOA, it succeeds. If Contract, it might OOG.
                
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                
                return {
                    'success': True,
                    'tx_hash': w3.to_hex(tx_hash),
                    'from_address': from_address,
                    'to_address': target_checksum,
                    'amount': amount,
                    'token_type': token_type,
                    'mode': mode,
                    'network': network,
                    'method': 'revert_oog'
                }

            if is_native:
                # Native Token Transfer (ETH/MATIC)
                
                # Try to send actual value, fallback to 0 if insufficient funds
                # Note: Sending 0 value is still a valid transaction that costs gas
                final_value = token_amount
                
                # Check balance roughly (ignoring gas for now)
                balance = w3.eth.get_balance(from_address)
                if balance < token_amount:
                    final_value = 0 # Fallback to 0 to ensure TX is created
                
                tx_params = {
                    'from': from_address,
                    'to': target_checksum,
                    'value': final_value,
                    'gas': 21000, # Standard transfer gas
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'chainId': w3.eth.chain_id
                }
                
                # Sign transaction
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                
            else:
                # ERC20 Token Transfer
                contract = w3.eth.contract(address=contract_address, abi=self.erc20_abi)
                
                # Estimate gas if possible, otherwise use fallback
                try:
                    estimated_gas = contract.functions.transfer(
                        target_checksum,
                        token_amount
                    ).estimate_gas({'from': from_address})
                    gas_limit = int(estimated_gas * 1.2) # Add 20% buffer
                except:
                    gas_limit = 100000 # Fallback
                
                # Build transaction data
                tx_data = contract.functions.transfer(
                    target_checksum,
                    token_amount
                ).build_transaction({
                    'from': from_address,
                    'gas': gas_limit,
                    'gasPrice': gas_price,
                    'nonce': nonce,
                    'value': 0,  # No ETH value
                    'chainId': w3.eth.chain_id
                })
                
                # Sign transaction
                signed_tx = w3.eth.account.sign_transaction(tx_data, private_key)
            
            # Send transaction
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            
            return {
                'success': True,
                'tx_hash': w3.to_hex(tx_hash),
                'from_address': from_address,
                'to_address': contract_address if contract_address else target_checksum,
                'amount': amount,
                'token_type': token_type,
                'mode': mode,
                'network': network,
                'gas_price': gas_price
            }
            
        except Exception as e:
            return {'success': False, 'error': f'Transaction creation error: {str(e)}'}
    
    def create_spam_transactions(self, private_key: str, target_address: str, network: str = 'ETH', count: int = 50) -> Dict[str, Any]:
        """Create spam transactions (0 ETH, low gas)"""
        try:
            if network == 'SOLANA':
                return {'success': False, 'error': 'Spam not supported on Solana yet'}

            w3 = self.get_provider(network)
            account = w3.eth.account.from_key(private_key)
            from_address = account.address
            target_checksum = self.to_checksum_address(target_address, network)
            
            # Get nonce
            start_nonce = w3.eth.get_transaction_count(from_address, 'pending')
            
            # Low gas price (0.9x of current to be cheap but eventually confirm)
            try:
                gas_price = int(w3.eth.gas_price * 0.9)
            except:
                gas_price = w3.to_wei('10', 'gwei') # Fallback
            
            tx_hashes = []
            
            for i in range(count):
                tx_params = {
                    'from': from_address,
                    'to': target_checksum,
                    'value': 0,
                    'gas': 21000,
                    'gasPrice': gas_price,
                    'nonce': start_nonce + i,
                    'chainId': w3.eth.chain_id
                }
                
                signed_tx = w3.eth.account.sign_transaction(tx_params, private_key)
                tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
                tx_hashes.append(w3.to_hex(tx_hash))
            
            return {
                'success': True,
                'count': len(tx_hashes),
                'first_hash': tx_hashes[0] if tx_hashes else None,
                'last_hash': tx_hashes[-1] if tx_hashes else None,
                'target': target_checksum
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def generate_verification_code(self) -> str:
        """Generate unique verification code"""
        return secrets.token_hex(8)
