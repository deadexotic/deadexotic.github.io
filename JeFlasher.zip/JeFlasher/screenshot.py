import os
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont
import pytz
import random
import requests

class ScreenshotGenerator:
    def __init__(self):
        self.width = 1170  # iPhone 13/14 Pro width
        self.height = 2532 # iPhone 13/14 Pro height
        
        # Colors
        self.themes = {
            'exodus': {
                'bg_color': (27, 29, 49), # Deep Navy/Purple
                'text_white': (255, 255, 255),
                'text_gray': (139, 149, 175),
                'green_success': (46, 204, 113),
                'separator_color': (40, 42, 55),
                'btn_color': (116, 124, 255) # Periwinkle Blue
            },
            'light': {
                'bg_color': (255, 255, 255),
                'text_white': (0, 0, 0),
                'text_gray': (100, 100, 100),
                'green_success': (46, 204, 113),
                'separator_color': (240, 240, 240),
                'btn_color': (0, 122, 255)
            },
            'phantom': {
                'bg_color': (34, 34, 34),
                'text_white': (255, 255, 255),
                'text_gray': (170, 170, 170),
                'green_success': (46, 204, 113),
                'separator_color': (50, 50, 50),
                'btn_color': (171, 159, 242) # Purple
            },
            'metamask': {
                'bg_color': (24, 26, 32), # Dark Grey
                'text_white': (255, 255, 255),
                'text_gray': (140, 140, 140),
                'green_success': (77, 182, 172), # Teal
                'separator_color': (45, 47, 55),
                'btn_color': (3, 118, 196) # Blue
            },
            'coinbase': {
                'bg_color': (0, 0, 0), # Deep black for OLED
                'text_white': (255, 255, 255),
                'text_gray': (142, 142, 147),
                'blue_primary': (10, 92, 255), # More vibrant Coinbase Blue
                'btn_color': (10, 92, 255)
            }
        }
        
        # Fonts
        self.font_path = "C:/Windows/Fonts/segoeui.ttf"
        self.font_bold_path = "C:/Windows/Fonts/segoeuib.ttf"
        
        # Cache for prices to avoid spamming API
        self.price_cache = {}
        self.last_price_update = 0
        
    def get_font(self, size, bold=False):
        try:
            path = self.font_bold_path if bold else self.font_path
            return ImageFont.truetype(path, size)
        except:
            return ImageFont.load_default()

    def get_token_price(self, token: str) -> float:
        """Get current token price in USD"""
        # Mapping for CoinGecko IDs
        token_map = {
            'USDC': 'usd-coin',
            'USDT': 'tether',
            'DAI': 'dai',
            'ETH': 'ethereum',
            'MATIC': 'matic-network',
            'SOL': 'solana',
            'UNI': 'uniswap',
            'LINK': 'chainlink'
        }
        
        # For stablecoins, add slight variance (0.998 to 1.002)
        if token in ['USDC', 'USDT', 'DAI']:
            return 0.998 + (random.random() * 0.004)
            
        try:
            url = f"https://api.coingecko.com/api/v3/simple/price?ids={token_map.get(token, 'ethereum')}&vs_currencies=usd"
            response = requests.get(url, timeout=5)
            data = response.json()
            return float(data[token_map.get(token)]['usd'])
        except:
            # Fallback prices
            defaults = {'ETH': 2500.0, 'MATIC': 0.8, 'SOL': 140.0, 'UNI': 7.0, 'LINK': 15.0}
            return defaults.get(token, 1.0)

    def generate_screenshot(self, amount: float, token: str, tx_hash: str, 
                          theme: str = 'exodus', timezone: str = 'UTC', 
                          network: str = 'ETH', mode: str = 'fast', target_address: str = "191jd3kGCWNWdpq4FnJCCUyhKCwd5sjn") -> str:
        """Generate a fake transaction screenshot"""
        
        current_theme = self.themes.get(theme, self.themes['exodus'])
        
        # Create image
        img = Image.new('RGB', (self.width, self.height), current_theme['bg_color'])
        draw = ImageDraw.Draw(img)
        
        # --- Status Bar ---
        try:
            # Handle GMT offsets manually if needed or use pytz
            if 'gmt' in timezone.lower() or 'utc' in timezone.lower():
                # Simple parsing for gmt+1 etc
                tz_name = timezone.lower()
                if '+' in tz_name:
                    offset = int(tz_name.split('+')[1])
                    tz = pytz.FixedOffset(offset * 60)
                elif '-' in tz_name:
                    offset = int(tz_name.split('-')[1])
                    tz = pytz.FixedOffset(-offset * 60)
                else:
                    tz = pytz.UTC
            else:
                tz = pytz.timezone(timezone)
            now = datetime.now(tz)
        except:
            now = datetime.now()
            
        time_str = now.strftime("%H:%M") # 24h format often default or based on locale, but user pic shows 11:51 (could be AM/PM). Let's stick to %H:%M or %I:%M based on user pref? Image shows "11:51" which is ambiguous. 
        # iOS usually follows system setting. Defaulting to 24h or 12h without AM/PM text usually in status bar.
        # Actually, iPhone status bar is just "9:41".
        time_str = now.strftime("%H:%M").lstrip("0") # Remove leading zero if any, e.g. 9:41
        if not time_str: time_str = "12:00" # Fallback
        
        # Draw Time (Top Left)
        # Using a slightly bolder font for time
        font_time = self.get_font(48, bold=True)
        # Time needs to be pushed down a bit for dynamic island/notch
        # Center the time in the rounded corner area
        draw.text((90, 55), time_str, fill=current_theme['text_white'], font=font_time)
        
        # Draw Signal/Wifi/Battery (Right side)
        icon_fill = current_theme['text_white']
        
        # Status Bar Right Area logic
        # Right margin
        right_margin = 60
        
        # --- Battery ---
        # Battery is rightmost
        # Size: ~75x35
        bat_w, bat_h = 70, 32
        bat_x = self.width - right_margin - bat_w
        bat_y = 60
        
        # Body (Outline) - Thicker, rounded
        # Outer
        draw.rounded_rectangle([bat_x, bat_y, bat_x + bat_w, bat_y + bat_h], radius=8, outline=(180, 180, 180), width=3) 
        
        # Inner Fill (Partial - ~70%)
        fill_width = bat_w * 0.7
        # Inset by 4px
        draw.rounded_rectangle([bat_x + 4, bat_y + 4, bat_x + fill_width, bat_y + bat_h - 4], radius=4, fill=icon_fill)
        
        # Cap (Nipple)
        cap_h = 12
        cap_w = 5
        # Draw solid cap
        draw.pieslice([bat_x + bat_w + 3, bat_y + (bat_h - cap_h)/2, bat_x + bat_w + 3 + cap_w*2, bat_y + (bat_h + cap_h)/2], start=90, end=270, fill=(180, 180, 180))
        # Wait, pieslice orientation is tricky. Let's use a small rounded rect or ellipse half.
        # Simple filled rectangle for cap
        draw.rounded_rectangle([bat_x + bat_w + 2, bat_y + (bat_h - cap_h)/2, bat_x + bat_w + 6, bat_y + (bat_h + cap_h)/2], radius=2, fill=(180, 180, 180))


        # --- Wifi ---
        # To the left of Battery
        # Spacing ~20px
        wifi_w = 50
        wifi_x = bat_x - 20 - wifi_w
        wifi_y = bat_y + bat_h - 2 # Bottom aligned roughly
        
        # Draw 3 arcs - Thicker and wider
        # Center of arcs
        wc_x = wifi_x + wifi_w / 2
        wc_y = wifi_y
        
        # Arc 3 (Top)
        draw.arc([wc_x - 24, wc_y - 24, wc_x + 24, wc_y + 24], start=225, end=315, fill=icon_fill, width=5)
        # Arc 2 (Middle)
        draw.arc([wc_x - 16, wc_y - 16, wc_x + 16, wc_y + 16], start=225, end=315, fill=icon_fill, width=5)
        # Arc 1 (Bottom Dot)
        draw.ellipse([wc_x - 4, wc_y - 4, wc_x + 4, wc_y + 4], fill=icon_fill)
        
        # --- Signal ---
        # To the left of Wifi
        # Spacing ~20px
        sig_w = 50 
        sig_x = wifi_x - 20 - sig_w
        sig_y_bottom = wifi_y + 2 # Align bottom
        
        # 4 bars
        # Heights: 12, 18, 24, 30
        bar_width = 9
        bar_gap = 5
        heights = [12, 18, 24, 30]
        
        for i in range(4):
            h = heights[i]
            x = sig_x + (bar_width + bar_gap) * i
            y = sig_y_bottom - h
            draw.rounded_rectangle([x, y, x + bar_width, sig_y_bottom], radius=3, fill=icon_fill)
        
        # --- Navigation Bar ---
        if theme == 'coinbase':
            # Draw Notification Banner
            self._draw_ios_notification(draw, amount, token, target_address, img)
            
            self._draw_coinbase_content(draw, amount, token, tx_hash, current_theme)
            filename = f"screenshot_{tx_hash[:8]}.png"
            img.save(filename)
            return filename

        # Back Arrow
        if theme == 'metamask':
             # MetaMask uses a different header style often, or just a simple back
             draw.text((50, 140), "←", fill=icon_fill, font=self.get_font(80))
        elif theme == 'phantom':
             draw.text((50, 140), "<", fill=icon_fill, font=self.get_font(80))
        else:
             draw.text((50, 140), "<", fill=icon_fill, font=self.get_font(80))
        
        # Title
        font_title = self.get_font(50, bold=True)
        if theme == 'phantom':
            title_text = "Sent"
        elif theme == 'metamask':
            title_text = f"Sent {token}"
        else:
            title_text = f"{token}"
            if network != 'ETH': 
                title_text += f" ({network})"
            
        # Approximate centering
        bbox_title = draw.textbbox((0, 0), title_text, font=font_title)
        title_w = bbox_title[2] - bbox_title[0]
        draw.text(((self.width - title_w)/2, 160), title_text, fill=icon_fill, font=font_title)
        
        # Settings Icon / Share Icon
        if theme == 'phantom':
             # Share icon (box with arrow)
             draw.rectangle([1050, 150, 1090, 190], outline=current_theme['text_gray'], width=3)
             draw.line([1070, 150, 1070, 130], fill=current_theme['text_gray'], width=3)
        else:
             draw.ellipse([1050, 150, 1100, 200], outline=current_theme['text_gray'], width=3)

        # --- Main Content ---
        
        # "Sent" Status or Icon
        if theme == 'phantom':
             # Phantom has a big circle with checkmark or arrow
             # Draw circle
             c_x, c_y = self.width/2, 350
             r = 60
             draw.ellipse([c_x-r, c_y-r, c_x+r, c_y+r], fill=current_theme['btn_color'])
             # Arrow up/right
             draw.line([c_x-20, c_y+20, c_x+20, c_y-20], fill=(255,255,255), width=5)
             draw.line([c_x+20, c_y-20, c_x, c_y-20], fill=(255,255,255), width=5)
             draw.line([c_x+20, c_y-20, c_x+20, c_y], fill=(255,255,255), width=5)
             
        elif theme == 'metamask':
             # "Sent" is title
             pass
        else:
             font_sent = self.get_font(45)
             draw.text((self.width/2 - 50, 350), "Sent", fill=current_theme['text_gray'], font=font_sent)
        
        # Amount (Large)
        font_amount = self.get_font(110, bold=True)
        amount_str = f"-{amount:,.4f} {token}"
        if theme == 'phantom':
             amount_str = f"-{amount:,.4f} {token}"
        
        # Center amount calculation
        bbox = draw.textbbox((0, 0), amount_str, font=font_amount)
        text_width = bbox[2] - bbox[0]
        draw.text(((self.width - text_width) / 2, 450), amount_str, fill=current_theme['text_white'], font=font_amount)
        
        # USD Value
        price = self.get_token_price(token)
        usd_val = amount * price
        usd_str = f"-${usd_val:,.2f}"
        
        font_usd = self.get_font(50)
        bbox_usd = draw.textbbox((0, 0), usd_str, font=font_usd)
        usd_width = bbox_usd[2] - bbox_usd[0]
        draw.text(((self.width - usd_width) / 2, 580), usd_str, fill=current_theme['text_gray'], font=font_usd)
        
        # --- Details List ---
        start_y = 800
        row_height = 140
        
        # Date
        date_str = now.strftime("%b %d, %Y at %I:%M %p")
        self._draw_row(draw, start_y, "Date", date_str, current_theme)
        
        # Status
        self._draw_row(draw, start_y + row_height, "Status", "Success", current_theme, value_color=current_theme['green_success'])
        
        # To Address (Truncated)
        self._draw_row(draw, start_y + row_height*2, "To", "0x59...9D7", current_theme)
        
        # Network Fee (Adjust based on mode)
        if mode == 'superfast':
            fee = random.uniform(8.50, 15.00) # High fee for instant
        elif mode == 'fast':
            fee = random.uniform(2.50, 8.50)  # Medium fee
        else: # long
            fee = random.uniform(0.50, 2.50)  # Low fee
            
        self._draw_row(draw, start_y + row_height*3, "Network Fee", f"${fee:.2f}", current_theme)
        
        # Transaction ID
        if len(tx_hash) > 12:
            short_hash = f"{tx_hash[:6]}...{tx_hash[-6:]}"
        else:
            short_hash = tx_hash
        self._draw_row(draw, start_y + row_height*4, "Transaction ID", short_hash, current_theme)

        # --- Footer Button ---
        # "View on Blockchain"
        button_y = 2200
        font_btn = self.get_font(45)
        btn_text = "View on Blockchain"
        bbox_btn = draw.textbbox((0, 0), btn_text, font=font_btn)
        btn_w = bbox_btn[2] - bbox_btn[0]
        draw.text(((self.width - btn_w) / 2, button_y + 35), btn_text, fill=current_theme['btn_color'], font=font_btn)

        # Save
        filename = f"screenshot_{tx_hash[:8]}.png"
        img.save(filename)
        return filename

    def _draw_ios_notification(self, draw, amount, token, target_address, img):
        """Draw iOS Notification Banner"""
        banner_x = 35
        banner_y = 120
        banner_w = self.width - 70
        banner_h = 240
        
        # Background (Darker gray/almost black)
        bg_color = (35, 35, 35) 
        draw.rounded_rectangle([banner_x, banner_y, banner_x + banner_w, banner_y + banner_h], radius=40, fill=bg_color)
        
        # Header: Icon + Title + Time
        icon_x = banner_x + 35
        icon_y = banner_y + 35
        icon_size = 50
        
        # Icon Background (White)
        draw.rounded_rectangle([icon_x, icon_y, icon_x + icon_size, icon_y + icon_size], radius=12, fill='white')
        
        # --- High-Resolution Icon Drawing for Smoothness ---
        # Scale factor for anti-aliasing (4x)
        scale = 4
        icon_size_hi = icon_size * scale
        
        # Create high-res canvas (transparent background)
        icon_img = Image.new('RGBA', (icon_size_hi, icon_size_hi), (0, 0, 0, 0))
        draw_hi = ImageDraw.Draw(icon_img)
        
        # Dimensions at high res
        w, h = icon_size_hi, icon_size_hi
        margin = 6 * scale # Padding from edge
        stroke = 8.5 * scale # Slightly thinner stroke (was ~11px at 1x) -> ~8.5px looks cleaner
        
        # Colors
        blue = (66, 133, 244)
        green = (52, 168, 83)
        yellow = (251, 188, 5)
        red = (234, 67, 53)
        
        # Geometry Logic
        # The M shape:
        # Left Vertical: Blue
        # Right Vertical: Green (bottom), Yellow (top corner)
        # V Shape: Red
        
        # Coordinates (Inner box)
        x1, y1 = margin, margin
        x2, y2 = w - margin, h - margin
        
        # 1. Left Vertical Bar (Blue)
        # From top-left to bottom-left
        # Use rounded line caps for smoothness
        draw_hi.line([(x1, y1 + stroke/2), (x1, y2)], fill=blue, width=int(stroke))
        # Fix top-left corner to be square-ish for the M start? 
        # Actually M starts with a rounded corner.
        # Let's use a path approach.
        
        # 2. Right Vertical Bar (Green)
        # From somewhat below top-right to bottom-right
        # The Green part starts after the Yellow curve.
        # Let's say top 1/3 is Yellow, bottom 2/3 is Green.
        green_start_y = y1 + (y2 - y1) * 0.25
        draw_hi.line([(x2, green_start_y), (x2, y2)], fill=green, width=int(stroke))
        
        # 3. Top Right Corner (Yellow)
        # A short segment at the top right
        # Overlaps slightly with Green to avoid gaps
        draw_hi.line([(x2, y1 + stroke/2), (x2, green_start_y + stroke/2)], fill=yellow, width=int(stroke))
        
        # 4. Red V Shape
        # Left Diagonal: Top-Left to Center-Bottom
        # Right Diagonal: Top-Right to Center-Bottom
        
        # Center Point
        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2 + 5 * scale # Slightly below geometric center
        
        # Left Red Diagonal
        # From (x1, y1) to (cx, cy)
        draw_hi.line([(x1, y1 + stroke/2), (cx, cy)], fill=red, width=int(stroke))
        
        # Right Red Diagonal
        # From (x2, y1) to (cx, cy)
        draw_hi.line([(x2, y1 + stroke/2), (cx, cy)], fill=red, width=int(stroke))
        
        # 5. Fix Joints and Caps
        # The top-left and top-right corners need to look continuous with the vertical bars.
        # We can draw circles at the corners to round them off perfectly.
        
        # Top Left Corner (Red/Blue intersection) - Actually Red covers Blue at the fold?
        # The modern logo has the Red fold *over* the Blue.
        # So drawing Red last is correct.
        
        # Draw rounded caps at the top corners to smooth transitions
        # Top Left (Red color to match the V start)
        # But wait, the vertical bar is Blue. The corner is where they meet.
        # Let's draw a small circle at (x1, y1+stroke/2) with Red?
        # Actually, the vertical bar is Blue, the diagonal is Red.
        # The "fold" implies Red is on top.
        
        # Top Right Corner (Red/Yellow intersection)
        # Diagonal is Red, Vertical is Yellow.
        
        # Let's refine the V-shape join at the bottom (cx, cy).
        # It needs to be sharp or slightly rounded?
        # The logo has a sharp-ish V but with stroke width it gets rounded.
        # Let's draw a filled circle at the join to smooth it if needed, or rely on line overlap.
        # With standard PIL lines, the join might be ugly.
        # Let's use polygon for the V to be precise.
        
        # Red V Polygon (Better control)
        # Left Wing
        # Top-Left-Outer: (x1 - stroke/2, y1)
        # Top-Left-Inner: (x1 + stroke/2, y1)
        # Bottom-Tip: (cx, cy + stroke/2)
        # But this is hard with rotation.
        
        # Alternative: Use `joint='curve'` in `line`? PIL doesn't support it fully in `line`.
        # `line` supports `joint` parameter since recent versions, but `curve` might be `rounded`.
        # Let's stick to lines which have rounded caps by default? No, `line` is rectangular by default.
        # We need to manually draw circles at endpoints for roundness.
        
        # Re-draw with Round Caps Strategy:
        
        # Clear
        draw_hi.rectangle([0,0,w,h], fill=(0,0,0,0))
        
        # Helper to draw a thick line with rounded ends
        def draw_round_line(draw, p1, p2, color, width):
            draw.line([p1, p2], fill=color, width=width)
            # Draw circles at ends
            r = width / 2
            draw.ellipse([p1[0]-r, p1[1]-r, p1[0]+r, p1[1]+r], fill=color)
            draw.ellipse([p2[0]-r, p2[1]-r, p2[0]+r, p2[1]+r], fill=color)
            
        # 1. Left Vertical (Blue)
        # Top point: (x1, y1 + stroke/2)
        # Bottom point: (x1, y2 - stroke/2)
        # We want the top to be covered by the red fold, but the bottom to be rounded.
        # Draw vertical line
        draw_hi.line([(x1, y1 + stroke), (x1, y2 - stroke/2)], fill=blue, width=int(stroke))
        # Bottom cap
        draw_hi.ellipse([x1 - stroke/2, y2 - stroke, x1 + stroke/2, y2], fill=blue)
        # Top part (under red)
        draw_hi.rectangle([x1 - stroke/2, y1, x1 + stroke/2, y1 + stroke], fill=blue)

        # 2. Right Vertical (Green + Yellow)
        # Bottom Cap (Green)
        draw_hi.ellipse([x2 - stroke/2, y2 - stroke, x2 + stroke/2, y2], fill=green)
        # Green Line (Bottom 2/3)
        green_h = (y2 - y1) * 0.6
        green_top_y = y2 - green_h
        draw_hi.line([(x2, green_top_y), (x2, y2 - stroke/2)], fill=green, width=int(stroke))
        
        # Yellow Line (Top 1/3)
        draw_hi.line([(x2, y1 + stroke), (x2, green_top_y)], fill=yellow, width=int(stroke))
        # Fix joint between Green/Yellow
        draw_hi.rectangle([x2 - stroke/2, green_top_y - 2, x2 + stroke/2, green_top_y + 2], fill=green) # overlap slightly
        
        # 3. Red V (The Diagonals)
        # Left Diagonal: (x1, y1) to (cx, cy)
        # Right Diagonal: (x2, y1) to (cx, cy)
        
        # We need to handle the corners carefully.
        # The Red line starts at the top-left corner.
        # Draw a custom polygon for the Left Wing to handle the "Fold" appearance.
        # The fold means the red line appears to come from the left vertical.
        
        # Left Wing Line
        draw_hi.line([(x1, y1 + stroke/2), (cx, cy)], fill=red, width=int(stroke))
        # Top-Left Cap (Red) - Makes the corner round
        draw_hi.ellipse([x1 - stroke/2, y1, x1 + stroke/2, y1 + stroke], fill=red)
        
        # Right Wing Line
        draw_hi.line([(x2, y1 + stroke/2), (cx, cy)], fill=red, width=int(stroke))
        # Top-Right Cap (Red) - Makes the corner round
        # Wait, the top-right corner is Yellow in the logo (the curve is yellow).
        # The Red line stops before the curve?
        # Actually, looking at the logo:
        # The Red line goes all the way to the corner, but the *corner itself* is Red on the left, and Red on the right?
        # No, the Right vertical is Green/Yellow. The Red V connects to it.
        # The join at top-right: The Red diagonal overlaps the Yellow vertical.
        # So drawing Red cap on top-right is correct.
        draw_hi.ellipse([x2 - stroke/2, y1, x2 + stroke/2, y1 + stroke], fill=red)
        
        # Center Bottom Join (Round)
        draw_hi.ellipse([cx - stroke/2, cy - stroke/2, cx + stroke/2, cy + stroke/2], fill=red)
        
        # 4. Final Polish: Masking to ensure sharp edges if needed?
        # No, rounded is better.
        
        # Resize down with high-quality resampling (LANCZOS)
        icon_img_resized = icon_img.resize((icon_size, icon_size), resample=Image.Resampling.LANCZOS)
        
        # Paste onto main image (using alpha channel as mask)
        # Note: 'img' is RGB, so we just paste.
        img.paste(icon_img_resized, (icon_x, icon_y), icon_img_resized)

        # "Coinbase" Title

        font_title = self.get_font(42, bold=True) 
        draw.text((icon_x + icon_size + 20, icon_y - 2), "Coinbase", fill='white', font=font_title)
        
        # "now" Time
        font_now = self.get_font(38)
        bbox = draw.textbbox((0, 0), "now", font=font_now)
        now_w = bbox[2] - bbox[0]
        draw.text((banner_x + banner_w - 35 - now_w, icon_y + 2), "now", fill=(160, 160, 160), font=font_now)
        
        # Content
        content_y = icon_y + icon_size + 15
        font_body = self.get_font(40) 
        
        # Text Logic
        max_text_w = banner_w - 70
        full_text = f"You sent {amount} {token} to {target_address}"
        
        # Calculate text wrapping
        words = full_text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            bbox = draw.textbbox((0, 0), test_line, font=font_body)
            if bbox[2] - bbox[0] <= max_text_w:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
        lines.append(' '.join(current_line))
        
        # Draw up to 3 lines with proper spacing
        line_height = 52 # Slightly increased spacing
        for i, line in enumerate(lines[:3]):
            text_to_draw = line
            if i == 2 and len(lines) > 3:
                text_to_draw = line[:-3] + "..."
            elif i == 2 and len(line) > 30: 
                 text_to_draw = line[:30] + "..."
                 
            draw.text((icon_x, content_y + (i * line_height)), text_to_draw, fill='white', font=font_body)

    def _draw_coinbase_content(self, draw, amount, token, tx_hash, theme):
        # 1. Icon (Blue Circle with Checkmark)
        cx, cy = self.width / 2, 600 # Moved down slightly
        r = 130 # Slightly larger
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=theme['blue_primary'])
        
        # Draw Checkmark (Thicker)
        points = [
            (cx - 55, cy + 15),
            (cx - 15, cy + 55),
            (cx + 65, cy - 65)
        ]
        draw.line(points, fill='white', width=18, joint='curve')

        # 2. "Successfully sent"
        font_success = self.get_font(60) # Larger
        text = "Successfully sent"
        bbox = draw.textbbox((0, 0), text, font=font_success)
        w = bbox[2] - bbox[0]
        draw.text(((self.width - w) / 2, 850), text, fill=theme['text_white'], font=font_success)

        # 3. Fiat Amount (Large Blue)
        price = self.get_token_price(token)
        usd_val = amount * price
        usd_str = f"${usd_val:,.2f}"
        
        font_amount = self.get_font(140)
        bbox = draw.textbbox((0, 0), usd_str, font=font_amount)
        w = bbox[2] - bbox[0]
        draw.text(((self.width - w) / 2, 1000), usd_str, fill=theme['blue_primary'], font=font_amount)

        # 4. Crypto Amount (Gray)
        # Using 8 decimals for precision appearance
        crypto_str = f"{amount:.8f} {token}"
        font_crypto = self.get_font(55)
        bbox = draw.textbbox((0, 0), crypto_str, font=font_crypto)
        w = bbox[2] - bbox[0]
        draw.text(((self.width - w) / 2, 1200), crypto_str, fill=theme['text_gray'], font=font_crypto)

        # 5. Note
        note = "This transaction usually takes about 30 minutes"
        font_note = self.get_font(42)
        bbox = draw.textbbox((0, 0), note, font=font_note)
        w = bbox[2] - bbox[0]
        # This is usually closer to the button
        draw.text(((self.width - w) / 2, 1950), note, fill=theme['text_gray'], font=font_note)

        # 6. Done Button
        btn_y = 2050
        btn_h = 150
        btn_margin = 50
        # Check if rounded_rectangle is available (Pillow >= 8.2.0)
        if hasattr(draw, 'rounded_rectangle'):
            draw.rounded_rectangle(
                [btn_margin, btn_y, self.width - btn_margin, btn_y + btn_h],
                radius=75, # More rounded (pill shape)
                fill=theme['btn_color']
            )
        else:
            draw.rectangle(
                [btn_margin, btn_y, self.width - btn_margin, btn_y + btn_h],
                fill=theme['btn_color']
            )
        
        btn_text = "Done"
        font_btn = self.get_font(55)
        bbox = draw.textbbox((0, 0), btn_text, font=font_btn)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        # Center text in button
        text_y = btn_y + (btn_h - h) / 2 - 15 # approximate vertical center correction
        draw.text(((self.width - w) / 2, text_y), btn_text, fill='white', font=font_btn)

        # 7. View Transaction Link
        link_text = "View transaction"
        font_link = self.get_font(50) # Same as button? or slightly smaller/bold
        bbox = draw.textbbox((0, 0), link_text, font=font_link)
        w = bbox[2] - bbox[0]
        draw.text(((self.width - w) / 2, btn_y + btn_h + 80), link_text, fill=theme['text_white'], font=font_link)
        
        # 8. Home Indicator (Bottom Line)
        # White line at bottom
        draw.line([self.width/2 - 200, self.height - 30, self.width/2 + 200, self.height - 30], fill='white', width=10)

    def _draw_row(self, draw, y, label, value, theme, value_color=None):
        if value_color is None:
            value_color = theme['text_white']
            
        font_label = self.get_font(42)
        font_val = self.get_font(42)
        
        # Label (Left)
        draw.text((80, y), label, fill=theme['text_gray'], font=font_label)
        
        # Value (Right)
        # Calculate width to right-align properly
        bbox = draw.textbbox((0, 0), value, font=font_val)
        val_w = bbox[2] - bbox[0]
        draw.text((self.width - 80 - val_w, y), value, fill=value_color, font=font_val)
        
        # Separator
        draw.line([80, y + 100, self.width - 80, y + 100], fill=theme['separator_color'], width=2)
