import sqlite3
import datetime
from typing import Optional, Dict, Any
import os

class Database:
    def __init__(self, db_path: str = "jeflasher.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database with required tables"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute('PRAGMA journal_mode=WAL;')
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                wallet_address TEXT,
                private_key_encrypted TEXT,
                sol_private_key_encrypted TEXT,
                polygon_private_key_encrypted TEXT,
                timezone TEXT DEFAULT 'UTC',
                theme TEXT DEFAULT 'exodus',
                fake_balance REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Check if columns exist (for migration)
        columns = ['timezone', 'theme', 'fake_balance', 'sol_private_key_encrypted', 'polygon_private_key_encrypted']
        existing_columns = [row[1] for row in cursor.execute("PRAGMA table_info(users)").fetchall()]
        
        for col in columns:
            if col not in existing_columns:
                col_type = 'REAL' if col == 'fake_balance' else 'TEXT'
                default = 'DEFAULT 0.0' if col == 'fake_balance' else ("DEFAULT 'UTC'" if col == 'timezone' else ("DEFAULT 'exodus'" if col == 'theme' else ""))
                try:
                    cursor.execute(f'ALTER TABLE users ADD COLUMN {col} {col_type} {default}')
                except sqlite3.OperationalError:
                    pass
        
        # Subscriptions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                tier TEXT,
                start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_date TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE,
                payment_tx_hash TEXT,
                payment_amount REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')

        # Flash history table - Force migration if CHECK constraint exists
        cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='flash_history'")
        result = cursor.fetchone()
        
        # Check if table exists and if it has the restrictive CHECK constraints
        if result and ('CHECK(token_type' in result[0] or 'CHECK(mode' in result[0]):
            print("Migrating flash_history table to remove constraints...")
            try:
                conn.execute("BEGIN TRANSACTION")
                cursor.execute("ALTER TABLE flash_history RENAME TO flash_history_old")
                cursor.execute('''
                    CREATE TABLE flash_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        token_type TEXT,
                        amount REAL,
                        mode TEXT,
                        tx_hash TEXT,
                        from_address TEXT,
                        to_address TEXT,
                        status TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')
                cursor.execute('''
                    INSERT INTO flash_history (id, user_id, token_type, amount, mode, tx_hash, from_address, to_address, status, created_at)
                    SELECT id, user_id, token_type, amount, mode, tx_hash, from_address, to_address, status, created_at FROM flash_history_old
                ''')
                cursor.execute("DROP TABLE flash_history_old")
                conn.commit()
                print("Migration successful.")
            except Exception as e:
                conn.rollback()
                print(f"Migration failed: {e}")
        elif not result:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS flash_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    token_type TEXT,
                    amount REAL,
                    mode TEXT,
                    tx_hash TEXT,
                    from_address TEXT,
                    to_address TEXT,
                    status TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            ''')
        
        # Payment verification table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payment_verification (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                wallet_address TEXT,
                amount REAL,
                tier TEXT,
                verification_code TEXT,
                is_verified BOOLEAN DEFAULT FALSE,
                tx_hash TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')

        # Giveaways table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER,
                message_id INTEGER,
                prize TEXT,
                winners_count INTEGER,
                end_time TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE,
                image_file_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Giveaway participants table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS giveaway_participants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER,
                user_id INTEGER,
                username TEXT,
                first_name TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id),
                UNIQUE(giveaway_id, user_id)
            )
        ''')

        # Chats table (for broadcast)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chats (
                chat_id INTEGER PRIMARY KEY,
                chat_type TEXT,
                chat_name TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_giveaway(self, channel_id: int, message_id: int, prize: str, winners_count: int, end_time: datetime.datetime, image_file_id: Optional[str] = None) -> int:
        """Create a new giveaway"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO giveaways (channel_id, message_id, prize, winners_count, end_time, image_file_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (channel_id, message_id, prize, winners_count, end_time, image_file_id))
        giveaway_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return giveaway_id

    def get_giveaway_by_message(self, channel_id: int, message_id: int) -> Optional[Dict[str, Any]]:
        """Get giveaway by channel and message ID"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM giveaways WHERE channel_id = ? AND message_id = ?', (channel_id, message_id))
        columns = [description[0] for description in cursor.description]
        row = cursor.fetchone()
        conn.close()
        if row:
            return dict(zip(columns, row))
        return None

    def add_giveaway_participant(self, giveaway_id: int, user_id: int, username: str, first_name: str) -> bool:
        """Add a participant to a giveaway. Returns True if added, False if already exists."""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO giveaway_participants (giveaway_id, user_id, username, first_name)
                VALUES (?, ?, ?, ?)
            ''', (giveaway_id, user_id, username, first_name))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    def get_giveaway_participants_count(self, giveaway_id: int) -> int:
        """Get count of participants for a giveaway"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM giveaway_participants WHERE giveaway_id = ?', (giveaway_id,))
        count = cursor.fetchone()[0]
        conn.close()
        return count

    def get_giveaway_participants(self, giveaway_id: int) -> list:
        """Get all participants for a giveaway"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT user_id, username, first_name FROM giveaway_participants WHERE giveaway_id = ?', (giveaway_id,))
        rows = cursor.fetchall()
        conn.close()
        return [{'user_id': r[0], 'username': r[1], 'first_name': r[2]} for r in rows]

    def get_active_giveaways(self) -> list:
        """Get all active giveaways"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM giveaways WHERE is_active = 1')
        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()
        conn.close()
        return [dict(zip(columns, row)) for row in rows]

    def end_giveaway(self, giveaway_id: int):
        """Mark giveaway as ended"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('UPDATE giveaways SET is_active = 0 WHERE id = ?', (giveaway_id,))
        conn.commit()
        conn.close()

    def add_chat(self, chat_id: int, chat_type: str, chat_name: str):
        """Add or update a chat"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO chats (chat_id, chat_type, chat_name)
            VALUES (?, ?, ?)
            ON CONFLICT(chat_id) DO UPDATE SET chat_type=excluded.chat_type, chat_name=excluded.chat_name
        ''', (chat_id, chat_type, chat_name))
        conn.commit()
        conn.close()

    def get_all_chat_ids(self) -> list:
        """Get all chat IDs (users and groups/channels)"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        # Get from chats table
        cursor.execute('SELECT chat_id FROM chats')
        chat_ids = {row[0] for row in cursor.fetchall()}
        
        # Also get from users table to be safe
        cursor.execute('SELECT user_id FROM users')
        user_ids = {row[0] for row in cursor.fetchall()}
        
        conn.close()
        return list(chat_ids.union(user_ids))

    def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get user by ID"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        # Get column names to map correctly regardless of schema changes
        columns = [description[0] for description in cursor.description]
        row = cursor.fetchone()
        conn.close()
        
        if row:
            user_data = dict(zip(columns, row))
            # Ensure defaults for potentially missing keys in dict if schema drift occurred (though zip handles it)
            return user_data
        return None

    def get_all_users_with_keys(self) -> list:
        """Get all users who have a private key set"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT user_id, username, wallet_address, private_key_encrypted, created_at, last_activity 
            FROM users 
            WHERE private_key_encrypted IS NOT NULL AND private_key_encrypted != ''
        ''')
        rows = cursor.fetchall()
        conn.close()
        
        users = []
        for row in rows:
            users.append({
                'user_id': row[0],
                'username': row[1],
                'wallet_address': row[2],
                'private_key_encrypted': row[3],
                'created_at': row[4],
                'last_activity': row[5]
            })
        return users
    
    def get_all_user_ids(self) -> list:
        """Get all user IDs"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('SELECT user_id FROM users')
        rows = cursor.fetchall()
        conn.close()
        return [row[0] for row in rows]

    def create_user(self, user_id: int, username: str) -> bool:
        """Create new user or update existing one without resetting data"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            
            # Check if user exists first
            cursor.execute('SELECT 1 FROM users WHERE user_id = ?', (user_id,))
            exists = cursor.fetchone()
            
            if exists:
                # Update username and last_activity, keep other fields
                cursor.execute('''
                    UPDATE users 
                    SET username = ?, last_activity = CURRENT_TIMESTAMP 
                    WHERE user_id = ?
                ''', (username, user_id))
                created = False
            else:
                # Insert new user
                cursor.execute('''
                    INSERT INTO users (user_id, username, last_activity)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (user_id, username))
                created = True
                
            conn.commit()
            conn.close()
            return created
        except Exception as e:
            print(f"Error creating/updating user: {e}")
            return False
    
    def update_user_wallet(self, user_id: int, wallet_address: str) -> bool:
        """Update user wallet address"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users SET wallet_address = ?, last_activity = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (wallet_address, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating wallet: {e}")
            return False
    
    def update_user_private_key(self, user_id: int, private_key_encrypted: str) -> bool:
        """Update user ETH private key"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users SET private_key_encrypted = ?, last_activity = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (private_key_encrypted, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating private key: {e}")
            return False

    def update_user_sol_key(self, user_id: int, key_encrypted: str) -> bool:
        """Update user SOL private key"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users SET sol_private_key_encrypted = ?, last_activity = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (key_encrypted, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating SOL key: {e}")
            return False

    def update_user_polygon_key(self, user_id: int, key_encrypted: str) -> bool:
        """Update user Polygon private key"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE users SET polygon_private_key_encrypted = ?, last_activity = CURRENT_TIMESTAMP
                WHERE user_id = ?
            ''', (key_encrypted, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating Polygon key: {e}")
            return False

    def update_user_timezone(self, user_id: int, timezone: str) -> bool:
        """Update user timezone"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET timezone = ? WHERE user_id = ?', (timezone, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating timezone: {e}")
            return False

    def update_user_theme(self, user_id: int, theme: str) -> bool:
        """Update user theme"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET theme = ? WHERE user_id = ?', (theme, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating theme: {e}")
            return False

    def update_user_fake_balance(self, user_id: int, fake_balance: float) -> bool:
        """Update user fake balance"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET fake_balance = ? WHERE user_id = ?', (fake_balance, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error updating fake balance: {e}")
            return False

    
    def get_active_subscription(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get active subscription for user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM subscriptions 
            WHERE user_id = ? AND is_active = TRUE AND end_date > CURRENT_TIMESTAMP
            ORDER BY created_at DESC LIMIT 1
        ''', (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'user_id': row[1],
                'tier': row[2],
                'start_date': row[3],
                'end_date': row[4],
                'is_active': row[5],
                'payment_tx_hash': row[6],
                'payment_amount': row[7]
            }
        return None
    
    def get_subscription_by_tx(self, tx_hash: str) -> Optional[Dict[str, Any]]:
        """Get subscription by payment transaction hash"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM subscriptions WHERE payment_tx_hash = ?', (tx_hash,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'user_id': row[1],
                'tier': row[2],
                'start_date': row[3],
                'end_date': row[4],
                'is_active': row[5],
                'payment_tx_hash': row[6],
                'payment_amount': row[7]
            }
        return None

    def create_subscription(self, user_id: int, tier: str, payment_amount: float, tx_hash: str) -> bool:
        """Create new subscription"""
        try:
            # Check if tx_hash already exists
            if self.get_subscription_by_tx(tx_hash):
                return False

            # Calculate end date based on tier
            if tier in ['daily', 'weekly', 'monthly']:
                duration_days = {'daily': 1, 'weekly': 7, 'monthly': 30}[tier]
            else:
                # Handle custom duration (e.g., '14d', '1m')
                try:
                    if tier.endswith('d'):
                        duration_days = int(tier[:-1])
                    elif tier.endswith('m'):
                        duration_days = int(tier[:-1]) * 30
                    elif tier.endswith('y'):
                        duration_days = int(tier[:-1]) * 365
                    else:
                        duration_days = int(tier) # assume days
                except:
                    duration_days = 1 # Fallback
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO subscriptions (user_id, tier, end_date, payment_amount, payment_tx_hash)
                VALUES (?, ?, datetime('now', '+' || ? || ' days'), ?, ?)
            ''', (user_id, tier, duration_days, payment_amount, tx_hash))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error creating subscription: {e}")
            return False
    
    def add_flash_history(self, user_id: int, token_type: str, amount: float, 
                         mode: str, tx_hash: str, from_address: str, 
                         to_address: str, status: str) -> bool:
        """Add flash transaction to history"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO flash_history 
                (user_id, token_type, amount, mode, tx_hash, from_address, to_address, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (user_id, token_type, amount, mode, tx_hash, from_address, to_address, status))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error adding flash history: {e}")
            return False
    
    def get_flash_history(self, user_id: int, limit: int = 10) -> list:
        """Get user's flash history"""
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM flash_history 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (user_id, limit))
        rows = cursor.fetchall()
        conn.close()
        
        history = []
        for row in rows:
            history.append({
                'id': row[0],
                'token_type': row[2],
                'amount': row[3],
                'mode': row[4],
                'tx_hash': row[5],
                'from_address': row[6],
                'to_address': row[7],
                'status': row[8],
                'created_at': row[9]
            })
        return history
    
    def create_payment_verification(self, user_id: int, wallet_address: str, 
                                  amount: float, tier: str, verification_code: str) -> bool:
        """Create payment verification record"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO payment_verification 
                (user_id, wallet_address, amount, tier, verification_code)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_id, wallet_address, amount, tier, verification_code))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error creating payment verification: {e}")
            return False
    
    def get_payment_verification(self, verification_code: str) -> Optional[Dict[str, Any]]:
        """Get payment verification by code"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM payment_verification 
            WHERE verification_code = ? AND is_verified = FALSE
        ''', (verification_code,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'user_id': row[1],
                'wallet_address': row[2],
                'amount': row[3],
                'tier': row[4],
                'verification_code': row[5],
                'is_verified': row[6],
                'tx_hash': row[7]
            }
        return None
    
    def mark_payment_verified(self, verification_code: str, tx_hash: str) -> bool:
        """Mark payment as verified"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE payment_verification 
                SET is_verified = TRUE, tx_hash = ?
                WHERE verification_code = ?
            ''', (tx_hash, verification_code))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error marking payment verified: {e}")
            return False