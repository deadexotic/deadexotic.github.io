# Configuration for JeFlasher Bot
import os

class Config:
    # Bot Configuration
    BOT_TOKEN = os.environ.get('BOT_TOKEN', '8215520276:AAGOsdPcHXJZdVRKB8zUhnJGe5tO7Q_dWA0')
    ADMIN_USER_ID = int(os.environ.get('ADMIN_USER_ID', '8374440795'))
    
    # Ethereum Network Configuration
    ETH_RPC_URL = os.environ.get('ETH_RPC_URL', 'https://mainnet.infura.io/v3/ac29508311be412ba6b25b9254b7517e')
    ETHERSCAN_API_KEY = os.environ.get('ETHERSCAN_API_KEY', '')
    
    # Subscription Configuration (USD Prices)
    SUBSCRIPTION_PRICES = {
        'daily': float(os.environ.get('DAILY_PRICE', '5.0')),
        'weekly': float(os.environ.get('WEEKLY_PRICE', '15.0')),
        'monthly': float(os.environ.get('MONTHLY_PRICE', '20.0'))
    }
    
    # Payment Configuration
    PAYMENT_WALLET_ADDRESS = os.environ.get('PAYMENT_WALLET_ADDRESS', '0xbA25782d705719ca16793276b5822B67C1E465b8')
    
    # Token Contract Addresses (Mainnet)
    TOKEN_CONTRACTS = {
        'USDC': os.environ.get('USDC_CONTRACT', '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48'),
        'USDT': os.environ.get('USDT_CONTRACT', '0xdAC17F958D2ee523a2206206994597C13D831ec7'),
        'DAI': os.environ.get('DAI_CONTRACT', '0x6B175474E89094C44Da98b954EedeAC495271d0F')
    }
    
    # Flashing Configuration
    FLASH_SETTINGS = {
        'fast_mode_gas_multiplier': 1.0,  # 2x base gas price
        'long_mode_gas_divisor': 25,      # 1/10th base gas price
        'max_flash_amount': 100000000,      # Maximum flash amount
        'min_eth_balance': 0.001,         # Minimum ETH required for gas
        'default_gas_limit': 100000         # Gas limit for token transfers
    }
    
    # Database Configuration
    DATABASE_PATH = os.environ.get('DATABASE_PATH', 'jeflasher.db')
    
    # Security Configuration
    ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY', 'Sigmoid')  # Will generate if not provided
    
    # Rate Limiting
    RATE_LIMITS = {
        'flash_per_hour': 10,     # Maximum flashes per hour per user
        'flash_per_day': 50,      # Maximum flashes per day per user
        'payment_verification_timeout': 30  # 1 hour timeout for payment verification
    }