import unittest
import sys
import os
import tkinter as tk

# Add root dir to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sleaq_wallet import SleaqWallet, GraphicsEngine, ModernButton, ModernCard

class TestSleaqWallet(unittest.TestCase):
    def setUp(self):
        # Setup headless environment if possible or just mock
        self.app = SleaqWallet()
        # Don't run mainloop, just test logic and widget creation
        self.app.update()

    def tearDown(self):
        self.app.destroy()
        if os.path.exists("sleaq_wallet.json"):
            # Clean up or restore?
            pass

    def test_graphics_engine(self):
        # Test QR Code generation
        qr = GraphicsEngine.create_qr_code("test_address", size=100)
        self.assertIsNotNone(qr)
        
        # Test Gradient
        grad = GraphicsEngine.create_gradient_image(100, 100, "black", "white")
        self.assertIsNotNone(grad)
        
        # Test Rounded Rect
        rect = GraphicsEngine.create_rounded_rect_image(100, 100, 10, "red")
        self.assertIsNotNone(rect)

    def test_wallet_initialization(self):
        self.assertIsNotNone(self.app.wallet_data)
        self.assertTrue("ETH" in self.app.wallet_data)
        self.assertTrue("BTC" in self.app.wallet_data)
        self.assertTrue("SOL" in self.app.wallet_data)

    def test_navigation(self):
        self.app.navigate("Receive")
        self.assertEqual(self.app.active_page, "Receive")
        self.app.navigate("Dashboard") 
        self.assertEqual(self.app.active_page, "Dashboard")
        
    def test_details_navigation(self):
        self.app.navigate("Details:ETH")
        # active_page should be "Details:ETH"
        self.assertEqual(self.app.active_page, "Details:ETH")
        # Check if title updated
        self.assertEqual(self.app.page_title.cget("text"), "ETH Wallet")
        
    def test_refresh(self):
        # Just call it to ensure no error
        self.app.refresh_data("ETH")
        self.app.refresh_data()

if __name__ == "__main__":
    unittest.main()
